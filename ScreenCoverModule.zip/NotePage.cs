﻿using ScreenCoverModule.ScreenControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace ScreenCoverModule
{
    [Serializable]
    public class NotePage
    {
        public List<BitmapSource> candidateImages;

        public int MainCandidateImageIndex = 0;

        public List<Resizables> Notations;

        public CaptureArea PageArea;

        public NotePage()
        {
            candidateImages = new List<BitmapSource>();
            Notations = new List<Resizables>();
        }
    }
}
