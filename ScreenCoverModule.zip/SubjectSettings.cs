﻿using ScreenCoverModule;
using ScreenCoverModule.ScreenControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace ScreenCoverModule
{
    [Serializable]
    public class SubjectSettings
    {
        public int imgTolerance;
        public int imgDivision;
        public int RecTime;
        public enum TypesOfCtrls { NTextBox, Underline, Highlighter, CaptureArea, clickThru, NONE }

        public ControlProperties North;
        public ControlProperties West;
        public ControlProperties South;
        public ControlProperties East;
        public Rect RecordArea;

        public List<clickThru> Punches;
        public SubjectSettings()
        {
            imgTolerance = 32;
            imgDivision = 32;
            RecTime = 7;
            East = new UnderlineProperty(true);
            South = new NTextBoxProperty(true);
            West = new HighlighterProperty(true);
            North = new HighlighterProperty(false);
            Punches = new List<clickThru>();
            RecordArea = new Rect(70, 70, 230, 230);


        }
        public ControlProperties getPreset(MainWindow.circularSelect e)
        {
            switch (e)
            {
                case MainWindow.circularSelect.N:
                    return North;
                case MainWindow.circularSelect.W:
                    return West;
                case MainWindow.circularSelect.S:
                    return South;
                case MainWindow.circularSelect.E:
                    return East;
                default:
                    return null;
            }
        }
    }

    [Serializable]
    public abstract class ControlProperties
    {
        public Rect Dimensions;
        public SubjectSettings.TypesOfCtrls CtrlType;
    }
    [Serializable]
    public class NTextBoxProperty : ControlProperties
    {
        public Color TextColor;
        public double FontSize;
        public FontFamily FontType;
        public bool Italic;
        public bool Bold;
        public NTextBoxProperty(bool isVanilla)
        {
            CtrlType = SubjectSettings.TypesOfCtrls.NTextBox;
            if (isVanilla)
            {
                CtrlType = SubjectSettings.TypesOfCtrls.NTextBox;
                TextColor = Colors.Black;
                FontSize = 20;
                FontType = new FontFamily("맑은 고딕");
                Italic = Bold = false;
            }
        }
        
    }
    [Serializable]
    public class UnderlineProperty : ControlProperties
    {
        public Color lineColor;
        //0~100
        public int Roundness;
        public double Thick;
        public UnderlineProperty(bool isVanilla)
        {
            CtrlType = SubjectSettings.TypesOfCtrls.Underline;
            if (isVanilla)
            {
                lineColor = Colors.DarkRed;
                Roundness = 90;
                Thick = 5;
            }
        }
    }
    [Serializable]
    public class HighlighterProperty : ControlProperties
    {
        public Color outerColor;
        public Color innerColor;
        public double outerOpacity;
        public double innerOpacity;
        //0~100
        public int Roundness;
        public double Thick;
        
        public HighlighterProperty(bool VanillaType)
        {
            CtrlType = SubjectSettings.TypesOfCtrls.Highlighter;
            if (VanillaType)
            {
                outerColor = Colors.Transparent;
                innerColor = Colors.Yellow;
                innerOpacity = 0.4;
                outerOpacity = 1;
                Roundness = 0;
                Thick = 0;
            }
            else
            {
                outerColor = Colors.Red;
                innerColor = Colors.Transparent;
                innerOpacity = 1;
                outerOpacity = 1;
                Roundness = 50;
                Thick = 2.5;
            }
        }
    }
}
