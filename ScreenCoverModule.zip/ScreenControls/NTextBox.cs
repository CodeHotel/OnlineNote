﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ScreenCoverModule.ScreenControls
{
    [Serializable()]
    public class NTextBox : Resizables
    {
        public TextBox MainContent;
        public NTextBoxProperty presetTemp;
        static NTextBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(NTextBox), new FrameworkPropertyMetadata(typeof(NTextBox)));
        }

        #region 추상함수 도입
        public override void InitiateFromPreset(double x1, double y1, double x2, double y2, ControlProperties e)
        {
            presetTemp = e as NTextBoxProperty;
            ix1 = x1; iy1 = y1; ix2 = x2; iy2 = y2;
            construct = true;
        }
        protected override void EnforcePreset()
        {
            MainContent.Margin = new Thickness(ix1, iy1, 0, 0);
            MainContent.Height = iy2 - iy1; MainContent.Width = ix2 - ix1;
            NW.Margin = new Thickness(ix1 - 5, iy1 - 5, 0, 0);
            UP.Margin = new Thickness((ix1 + ix2) / 2 - 5, iy1 - 5, 0, 0);
            NE.Margin = new Thickness(ix2 - 5, iy1 - 5, 0, 0);
            LEFT.Margin = new Thickness(ix1 - 5, (iy1 + iy2) / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(ix2 - 5, (iy1 + iy2) / 2 - 5, 0, 0);
            SW.Margin = new Thickness(ix1 - 5, iy2 - 5, 0, 0);
            DOWN.Margin = new Thickness((ix1 + ix2) / 2 - 5, iy2 - 5, 0, 0);
            SE.Margin = new Thickness(ix2 - 5, iy2 - 5, 0, 0);

            LUp.X1 = RN.X1 = ix1; LUp.X2 = RN.X2 = ix2; LUp.Y1 = LUp.Y2 = RN.Y1 = RN.Y2 = iy1;
            LDown.X1 = RS.X1 = ix1; LDown.X2 = RS.X2 = ix2; LDown.Y1 = LDown.Y2 = RS.Y1 = RS.Y2 = iy2;
            LLeft.X1 = LLeft.X2 = RW.X1 = RW.X2 = ix1; LLeft.Y1 = RW.Y1 = iy1; LLeft.Y2 = RW.Y2 = iy2;
            LRight.X1 = LRight.X2 = RE.X1 = RE.X2 = ix2; LRight.Y1 = RE.Y1 = iy1; LRight.Y2 = RE.Y2 = iy2;
            
            MainContent.Foreground = new SolidColorBrush(presetTemp.TextColor);
            MainContent.FontSize = presetTemp.FontSize;
            MainContent.FontFamily = presetTemp.FontType;
            if (presetTemp.Bold) { MainContent.FontWeight = FontWeights.Bold; }
            else { MainContent.FontWeight = FontWeights.Normal; }
            if (presetTemp.Italic) { MainContent.FontStyle = FontStyles.Italic; }
            else { MainContent.FontStyle = FontStyles.Normal; }


        }
        public override void moveByKey(KeyEventArgs e)
        {
            
            Thickness newMargin; 
            switch (e.Key)
            {
                case Key.Up:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(MainContent.Margin.Left, MainContent.Margin.Top - 1, MainContent.Width, MainContent.Height))) { return; }
                    newMargin = new Thickness(MainContent.Margin.Left, MainContent.Margin.Top - 1, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                case Key.Down:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(MainContent.Margin.Left, MainContent.Margin.Top + 1, MainContent.Width, MainContent.Height))) { return; }
                    newMargin = new Thickness(MainContent.Margin.Left, MainContent.Margin.Top + 1, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                case Key.Left:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(MainContent.Margin.Left - 1, MainContent.Margin.Top, MainContent.Width, MainContent.Height))) { return; }
                    newMargin = new Thickness(MainContent.Margin.Left - 1, MainContent.Margin.Top, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                case Key.Right:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(MainContent.Margin.Left + 1, MainContent.Margin.Top, MainContent.Width, MainContent.Height))) { return; }
                    newMargin = new Thickness(MainContent.Margin.Left + 1, MainContent.Margin.Top, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                default:
                    return;
            }
            NW.Margin = new Thickness(MainContent.Margin.Left - 5, MainContent.Margin.Top - 5, 0, 0);
            SE.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width - 5, MainContent.Margin.Top + MainContent.Height - 5, 0, 0);
            UP.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width / 2 - 5, MainContent.Margin.Top - 5, 0, 0);
            DOWN.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width / 2 - 5, MainContent.Margin.Top + MainContent.Height - 5, 0, 0);
            LEFT.Margin = new Thickness(MainContent.Margin.Left - 5, MainContent.Margin.Top + MainContent.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width - 5, MainContent.Margin.Top + MainContent.Height / 2 - 5, 0, 0);
            NE.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width - 5, MainContent.Margin.Top - 5, 0, 0);
            SW.Margin = new Thickness(MainContent.Margin.Left - 5, MainContent.Margin.Top + MainContent.Height - 5, 0, 0);

            LUp.X1 = RN.X1 = MainContent.Margin.Left; LUp.Y1 = RN.Y1 = MainContent.Margin.Top; LUp.X2 = RN.X2 = MainContent.Margin.Left + MainContent.Width; LUp.Y2 = RN.Y2 = MainContent.Margin.Top;
            LDown.X1 = RS.X1 = MainContent.Margin.Left; LDown.Y1 = RS.Y1 = MainContent.Margin.Top + MainContent.Height; LDown.X2 = RS.X2 = MainContent.Margin.Left + MainContent.Width; LDown.Y2 = RS.Y2 = MainContent.Margin.Top + MainContent.Height;
            LLeft.X1 = RW.X1 = MainContent.Margin.Left; LLeft.Y1 = RW.Y1 = MainContent.Margin.Top; LLeft.X2 = RW.X2 = MainContent.Margin.Left; LLeft.Y2 = RW.Y2 = MainContent.Margin.Top + MainContent.Height;
            LRight.X1 = RE.X1 = MainContent.Margin.Left + MainContent.Width; LRight.Y1 = RE.Y1 = MainContent.Margin.Top; LRight.X2 = RE.X2 = MainContent.Margin.Left + MainContent.Width; LRight.Y2 = RE.Y2 = MainContent.Margin.Top + MainContent.Height; 
        }
        public override void CtrlsShown(SelectMode PrevMode, SelectMode NewMode)
        {
            if (NE == null) { return; }
            switch (NewMode)
            {
                case SelectMode.NON:
                    #region 외곽 숨기기
                    NE.Visibility = Visibility.Hidden;
                    SW.Visibility = Visibility.Hidden;
                    SE.Visibility = Visibility.Hidden;
                    NW.Visibility = Visibility.Hidden;
                    UP.Visibility = Visibility.Hidden;
                    DOWN.Visibility = Visibility.Hidden;
                    LEFT.Visibility = Visibility.Hidden;
                    RIGHT.Visibility = Visibility.Hidden;
                    RN.Visibility = Visibility.Hidden;
                    RE.Visibility = Visibility.Hidden;
                    RW.Visibility = Visibility.Hidden;
                    RS.Visibility = Visibility.Hidden;
                    #endregion
                    #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록 해제
                    if (MainContent != null)
                    {
                        (MainContent as TextBox).MouseMove -= Leave_Regulator;
                        (MainContent as TextBox).KeyDown -= TextKeyDown;
                        (MainContent as TextBox).MouseDown -= TextClick;
                    }
                    if (LUp != null)
                    {
                        (LUp as Line).MouseEnter -= Line_MouseEnter;
                        (LUp as Line).MouseDown -= LineMouseDown;
                        (LUp as Line).MouseMove -= Movement_Regulator;
                    }
                    if (LDown != null)
                    {
                        (LDown as Line).MouseEnter -= Line_MouseEnter;
                        (LDown as Line).MouseDown -= LineMouseDown;
                        (LDown as Line).MouseMove -= Movement_Regulator;
                    }
                    if (LRight != null)
                    {
                        (LRight as Line).MouseEnter -= Line_MouseEnter;
                        (LRight as Line).MouseDown -= LineMouseDown;
                        (LRight as Line).MouseMove -= Movement_Regulator;
                    }
                    if (LLeft != null)
                    {
                        (LLeft as Line).MouseEnter -= Line_MouseEnter;
                        (LLeft as Line).MouseDown -= LineMouseDown;
                        (LLeft as Line).MouseMove -= Movement_Regulator;
                    }

                    if (NW != null)
                    {
                        (NW as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                        (NW as Rectangle).MouseDown -= NWMouseDown;
                        (NW as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (SE != null)
                    {
                        (SE as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                        (SE as Rectangle).MouseDown -= SEMouseDown;
                        (SE as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (UP != null)
                    {
                        (UP as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                        (UP as Rectangle).MouseDown -= UPMouseDown;
                        (UP as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (DOWN != null)
                    {
                        (DOWN as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                        (DOWN as Rectangle).MouseDown -= DOWNMouseDown;
                        (DOWN as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (LEFT != null)
                    {
                        (LEFT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (LEFT as Rectangle).MouseDown -= LEFTMouseDown;
                        (LEFT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (RIGHT != null)
                    {
                        (RIGHT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (RIGHT as Rectangle).MouseDown -= RIGHTMouseDown;
                        (RIGHT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (NE != null)
                    {
                        (NE as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                        (NE as Rectangle).MouseDown -= NEMouseDown;
                        (NE as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (SW != null)
                    {
                        (SW as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                        (SW as Rectangle).MouseDown -= SWMouseDown;
                        (SW as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    #endregion
                    if (MainContent.IsFocused)
                    {
                        //FocusManager.SetFocusedElement(FocusManager.GetFocusScope(MainContent), null);
                        //Keyboard.ClearFocus();
                    }
                    break;
                case SelectMode.MOV:
                    //FocusManager.SetFocusedElement(FocusManager.GetFocusScope(MainContent), null);
                    //Keyboard.ClearFocus();
                    switch (PrevMode)
                    {
                        case SelectMode.TXT:
                            break;
                        case SelectMode.NON:
                            #region 외곽 보이기
                            NE.Visibility = Visibility.Visible;
                            SW.Visibility = Visibility.Visible;
                            SE.Visibility = Visibility.Visible;
                            NW.Visibility = Visibility.Visible;
                            UP.Visibility = Visibility.Visible;
                            DOWN.Visibility = Visibility.Visible;
                            LEFT.Visibility = Visibility.Visible;
                            RIGHT.Visibility = Visibility.Visible;
                            RN.Visibility = Visibility.Visible;
                            RE.Visibility = Visibility.Visible;
                            RW.Visibility = Visibility.Visible;
                            RS.Visibility = Visibility.Visible;
                            #endregion
                            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
                            if (MainContent != null)
                            {
                                (MainContent as TextBox).MouseMove += Leave_Regulator;
                                (MainContent as TextBox).KeyDown += TextKeyDown;
                                (MainContent as TextBox).MouseDown += TextClick;
                            }
                            if (LUp != null)
                            {
                                (LUp as Line).MouseEnter += Line_MouseEnter;
                                (LUp as Line).MouseDown += LineMouseDown;
                                (LUp as Line).MouseMove += Movement_Regulator;
                            }
                            if (LDown != null)
                            {
                                (LDown as Line).MouseEnter += Line_MouseEnter;
                                (LDown as Line).MouseDown += LineMouseDown;
                                (LDown as Line).MouseMove += Movement_Regulator;
                            }
                            if (LRight != null)
                            {
                                (LRight as Line).MouseEnter += Line_MouseEnter;
                                (LRight as Line).MouseDown += LineMouseDown;
                                (LRight as Line).MouseMove += Movement_Regulator;
                            }
                            if (LLeft != null)
                            {
                                (LLeft as Line).MouseEnter += Line_MouseEnter;
                                (LLeft as Line).MouseDown += LineMouseDown;
                                (LLeft as Line).MouseMove += Movement_Regulator;
                            }

                            if (NW != null)
                            {
                                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (NW as Rectangle).MouseDown += NWMouseDown;
                                (NW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SE != null)
                            {
                                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (SE as Rectangle).MouseDown += SEMouseDown;
                                (SE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (UP != null)
                            {
                                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (UP as Rectangle).MouseDown += UPMouseDown;
                                (UP as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (DOWN != null)
                            {
                                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                                (DOWN as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (LEFT != null)
                            {
                                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                                (LEFT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (RIGHT != null)
                            {
                                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (NE != null)
                            {
                                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (NE as Rectangle).MouseDown += NEMouseDown;
                                (NE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SW != null)
                            {
                                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (SW as Rectangle).MouseDown += SWMouseDown;
                                (SW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            #endregion
                            break;
                    }
                    break;
                case SelectMode.TXT:
                    switch (PrevMode)
                    {
                        case SelectMode.MOV:
                            break;
                        case SelectMode.NON:
                            #region 외곽 보이기
                            NE.Visibility = Visibility.Visible;
                            SW.Visibility = Visibility.Visible;
                            SE.Visibility = Visibility.Visible;
                            NW.Visibility = Visibility.Visible;
                            UP.Visibility = Visibility.Visible;
                            DOWN.Visibility = Visibility.Visible;
                            LEFT.Visibility = Visibility.Visible;
                            RIGHT.Visibility = Visibility.Visible;
                            RN.Visibility = Visibility.Visible;
                            RE.Visibility = Visibility.Visible;
                            RW.Visibility = Visibility.Visible;
                            RS.Visibility = Visibility.Visible;
                            #endregion
                            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
                            if (MainContent != null)
                            {
                                (MainContent as TextBox).MouseMove += Leave_Regulator;
                                (MainContent as TextBox).KeyDown += TextKeyDown;
                                (MainContent as TextBox).MouseDown += TextClick;
                            }
                            if (LUp != null)
                            {
                                (LUp as Line).MouseEnter += Line_MouseEnter;
                                (LUp as Line).MouseDown += LineMouseDown;
                                (LUp as Line).MouseMove += Movement_Regulator;
                            }
                            if (LDown != null)
                            {
                                (LDown as Line).MouseEnter += Line_MouseEnter;
                                (LDown as Line).MouseDown += LineMouseDown;
                                (LDown as Line).MouseMove += Movement_Regulator;
                            }
                            if (LRight != null)
                            {
                                (LRight as Line).MouseEnter += Line_MouseEnter;
                                (LRight as Line).MouseDown += LineMouseDown;
                                (LRight as Line).MouseMove += Movement_Regulator;
                            }
                            if (LLeft != null)
                            {
                                (LLeft as Line).MouseEnter += Line_MouseEnter;
                                (LLeft as Line).MouseDown += LineMouseDown;
                                (LLeft as Line).MouseMove += Movement_Regulator;
                            }

                            if (NW != null)
                            {
                                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (NW as Rectangle).MouseDown += NWMouseDown;
                                (NW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SE != null)
                            {
                                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (SE as Rectangle).MouseDown += SEMouseDown;
                                (SE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (UP != null)
                            {
                                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (UP as Rectangle).MouseDown += UPMouseDown;
                                (UP as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (DOWN != null)
                            {
                                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                                (DOWN as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (LEFT != null)
                            {
                                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                                (LEFT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (RIGHT != null)
                            {
                                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (NE != null)
                            {
                                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (NE as Rectangle).MouseDown += NEMouseDown;
                                (NE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SW != null)
                            {
                                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (SW as Rectangle).MouseDown += SWMouseDown;
                                (SW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            #endregion
                            break;
                    }
                    break;
            }
        }

        public override void Movement_Regulator(object sender, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed)
            {
                return;
            }
            Thickness newMargin;
            double iw, ih, rx, ry, rw, rh;
            switch (ClickMode)
            {
                case HTarget.LINE:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(ox1 + e.GetPosition(null).X - cpx, oy1 + e.GetPosition(null).Y - cpy, MainContent.Width, MainContent.Height))) { return; }
                    newMargin = new Thickness(ox1 + e.GetPosition(null).X - cpx, oy1 + e.GetPosition(null).Y - cpy, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                case HTarget.NW:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    rx = ox2 - iw; ry = oy2 - ih; rw = iw; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { MainContent.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { MainContent.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox2 - iw, oy2 - ih, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                case HTarget.UP:
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    rx = ox1; ry = oy2 - ih; rw = MainContent.Width; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (ih >= 20) { MainContent.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox1, oy2 - ih, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                case HTarget.NE:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    rx = ox1; ry = oy2 - ih; rw = iw; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { MainContent.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { MainContent.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox1, oy2 - ih, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                case HTarget.LEFT:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    rx = ox2 - iw; ry = oy1; rw = iw; rh = MainContent.Height;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { MainContent.Width = iw; } else { iw = 20; }
                    newMargin = new Thickness(ox2 - iw, oy1, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                case HTarget.RIGHT:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    rx = MainContent.Margin.Left; ry = MainContent.Margin.Top; rw = iw; rh = MainContent.Height;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { MainContent.Width = iw; } else { iw = 20; }
                    break;
                case HTarget.SW:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    rx = ox2 - iw; ry = oy1; rw = iw; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { MainContent.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { MainContent.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox2 - iw, oy1, 0, 0);
                    MainContent.Margin = newMargin;
                    break;
                case HTarget.DOWN:
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    rx = MainContent.Margin.Left; ry = MainContent.Margin.Top; rw = MainContent.Width; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (ih >= 20) { MainContent.Height = ih; } else { ih = 20; }
                    break;
                case HTarget.SE:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    rx = MainContent.Margin.Left; ry = MainContent.Margin.Top; rw = iw; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { MainContent.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { MainContent.Height = ih; } else { ih = 20; }
                    break;

                default:
                    break;
            }
            NW.Margin = new Thickness(MainContent.Margin.Left - 5, MainContent.Margin.Top - 5, 0, 0);
            SE.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width - 5, MainContent.Margin.Top + MainContent.Height - 5, 0, 0);
            UP.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width / 2 - 5, MainContent.Margin.Top - 5, 0, 0);
            DOWN.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width / 2 - 5, MainContent.Margin.Top + MainContent.Height - 5, 0, 0);
            LEFT.Margin = new Thickness(MainContent.Margin.Left - 5, MainContent.Margin.Top + MainContent.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width - 5, MainContent.Margin.Top + MainContent.Height / 2 - 5, 0, 0);
            NE.Margin = new Thickness(MainContent.Margin.Left + MainContent.Width - 5, MainContent.Margin.Top - 5, 0, 0);
            SW.Margin = new Thickness(MainContent.Margin.Left - 5, MainContent.Margin.Top + MainContent.Height - 5, 0, 0);

            LUp.X1 = RN.X1 = MainContent.Margin.Left; LUp.Y1 = RN.Y1 = MainContent.Margin.Top; LUp.X2 = RN.X2 = MainContent.Margin.Left + MainContent.Width; LUp.Y2 = RN.Y2 = MainContent.Margin.Top;
            LDown.X1 = RS.X1 = MainContent.Margin.Left; LDown.Y1 = RS.Y1 = MainContent.Margin.Top + MainContent.Height; LDown.X2 = RS.X2 = MainContent.Margin.Left + MainContent.Width; LDown.Y2 = RS.Y2 = MainContent.Margin.Top + MainContent.Height;
            LLeft.X1 = RW.X1 = MainContent.Margin.Left; LLeft.Y1 = RW.Y1 = MainContent.Margin.Top; LLeft.X2 = RW.X2 = MainContent.Margin.Left; LLeft.Y2 = RW.Y2 = MainContent.Margin.Top + MainContent.Height;
            LRight.X1 = RE.X1 = MainContent.Margin.Left + MainContent.Width; LRight.Y1 = RE.Y1 = MainContent.Margin.Top; LRight.X2 = RE.X2 = MainContent.Margin.Left + MainContent.Width; LRight.Y2 = RE.Y2 = MainContent.Margin.Top + MainContent.Height;
        }

        protected override void MainContent_Resize(double x1, double y1, double x2, double y2)
        {
            MainContent.Margin = new Thickness(x1, y1, 0, 0);
            MainContent.Height = y2 - y1; MainContent.Width = x2 - x1;
        }
        #endregion

        #region 구동함수
        //구동함수
        public override void OnApplyTemplate()
        {
            #region 레퍼런스 변수에 각 구성요소 등록
            LUp = Template.FindName("LUp", this) as Line;
            LDown = Template.FindName("LDown", this) as Line;
            LLeft = Template.FindName("LLeft", this) as Line;
            LRight = Template.FindName("LRight", this) as Line;

            MainContent = Template.FindName("MainContent", this) as TextBox;

            NE = Template.FindName("NE", this) as Rectangle;
            NW = Template.FindName("NW", this) as Rectangle;
            SE = Template.FindName("SE", this) as Rectangle;
            SW = Template.FindName("SW", this) as Rectangle;
            UP = Template.FindName("UP", this) as Rectangle;
            DOWN = Template.FindName("DOWN", this) as Rectangle;
            RIGHT = Template.FindName("RIGHT", this) as Rectangle;
            LEFT = Template.FindName("LEFT", this) as Rectangle;

            RN = Template.FindName("RN", this) as Line;
            RW = Template.FindName("RW", this) as Line;
            RE = Template.FindName("RE", this) as Line;
            RS = Template.FindName("RS", this) as Line;

            #endregion
            this.MouseUp += TxtMouseUp;
            this.MouseLeave += Leave_Regulator;
            //this.LostFocus += TxtLostFocus;
            //this.GotFocus += TxtGainedFocus;
            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
            if (MainContent != null)
            {
                (MainContent as TextBox).MouseMove += Leave_Regulator;
                (MainContent as TextBox).KeyDown += TextKeyDown;
                (MainContent as TextBox).GotFocus += TextClick;
                MainContent.Focus();
            }
            if (LUp != null)
            {
                (LUp as Line).MouseEnter += Line_MouseEnter;
                (LUp as Line).MouseDown += LineMouseDown;
                (LUp as Line).MouseMove += Movement_Regulator;
            }
            if (LDown != null)
            {
                (LDown as Line).MouseEnter += Line_MouseEnter;
                (LDown as Line).MouseDown += LineMouseDown;
                (LDown as Line).MouseMove += Movement_Regulator;
            }
            if (LRight != null)
            {
                (LRight as Line).MouseEnter += Line_MouseEnter;
                (LRight as Line).MouseDown += LineMouseDown;
                (LRight as Line).MouseMove += Movement_Regulator;
            }
            if (LLeft != null)
            {
                (LLeft as Line).MouseEnter += Line_MouseEnter;
                (LLeft as Line).MouseDown += LineMouseDown;
                (LLeft as Line).MouseMove += Movement_Regulator;
            }

            if (NW != null)
            {
                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (NW as Rectangle).MouseDown += NWMouseDown;
                (NW as Rectangle).MouseMove += Movement_Regulator;
            }
            if (SE != null)
            {
                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (SE as Rectangle).MouseDown += SEMouseDown;
                (SE as Rectangle).MouseMove += Movement_Regulator;
            }
            if (UP != null)
            {
                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (UP as Rectangle).MouseDown += UPMouseDown;
                (UP as Rectangle).MouseMove += Movement_Regulator;
            }
            if (DOWN != null)
            {
                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                (DOWN as Rectangle).MouseMove += Movement_Regulator;
            }
            if (LEFT != null)
            {
                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                (LEFT as Rectangle).MouseMove += Movement_Regulator;
            }
            if (RIGHT != null)
            {
                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
            }
            if (NE != null)
            {
                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (NE as Rectangle).MouseDown += NEMouseDown;
                (NE as Rectangle).MouseMove += Movement_Regulator;
            }
            if (SW != null)
            {
                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (SW as Rectangle).MouseDown += SWMouseDown;
                (SW as Rectangle).MouseMove += Movement_Regulator;
            }
            #endregion

            if (construct) EnforcePreset();
            base.OnApplyTemplate();
            
        }
        #endregion


        #region Text관련 작업처리
        private void TextKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                int CaretTmp = MainContent.CaretIndex;
                MainContent.Text = MainContent.Text.Substring(0, MainContent.CaretIndex) + "\n" + MainContent.Text.Substring(MainContent.CaretIndex);
                //MainContent.Focus();
                MainContent.Select(CaretTmp + 1, 0);
            }

        }

        private void TextClick(object sender, RoutedEventArgs e)
        {
            SelVarChange = SelectMode.TXT;
        }

        public Rect getRect()
        {
            return new Rect(MainContent.Margin.Left, MainContent.Margin.Top, MainContent.Width, MainContent.Height);
        }
        #endregion
    }
}
