﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;

namespace ScreenCoverModule.ScreenControls
{
    [Serializable()]
    public class clickThru : Resizables
    {
        public Rectangle innerRect;

        static clickThru()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(clickThru), new FrameworkPropertyMetadata(typeof(clickThru)));
        }

        #region 추상함수 도입
        public override void moveByKey(KeyEventArgs e)
        {

            Thickness newMargin;
            switch (e.Key)
            {
                case Key.Up:
                    if (RectToRect(CaptureArea.currentRect).IntersectsWith(new Rect(innerRect.Margin.Left, innerRect.Margin.Top - 1, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left, innerRect.Margin.Top - 1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case Key.Down:
                    if (RectToRect(CaptureArea.currentRect).IntersectsWith(new Rect(innerRect.Margin.Left, innerRect.Margin.Top + 1, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left, innerRect.Margin.Top + 1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case Key.Left:
                    if (RectToRect(CaptureArea.currentRect).IntersectsWith(new Rect(innerRect.Margin.Left - 1, innerRect.Margin.Top, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left - 1, innerRect.Margin.Top, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case Key.Right:
                    if (RectToRect(CaptureArea.currentRect).IntersectsWith(new Rect(innerRect.Margin.Left + 1, innerRect.Margin.Top, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left + 1, innerRect.Margin.Top, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                default:
                    return;
            }
            NW.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top - 5, 0, 0);
            SE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            UP.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top - 5, 0, 0);
            DOWN.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            LEFT.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            NE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top - 5, 0, 0);
            SW.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);

            LUp.X1 = RN.X1 = innerRect.Margin.Left; LUp.Y1 = RN.Y1 = innerRect.Margin.Top; LUp.X2 = RN.X2 = innerRect.Margin.Left + innerRect.Width; LUp.Y2 = RN.Y2 = innerRect.Margin.Top;
            LDown.X1 = RS.X1 = innerRect.Margin.Left; LDown.Y1 = RS.Y1 = innerRect.Margin.Top + innerRect.Height; LDown.X2 = RS.X2 = innerRect.Margin.Left + innerRect.Width; LDown.Y2 = RS.Y2 = innerRect.Margin.Top + innerRect.Height;
            LLeft.X1 = RW.X1 = innerRect.Margin.Left; LLeft.Y1 = RW.Y1 = innerRect.Margin.Top; LLeft.X2 = RW.X2 = innerRect.Margin.Left; LLeft.Y2 = RW.Y2 = innerRect.Margin.Top + innerRect.Height;
            LRight.X1 = RE.X1 = innerRect.Margin.Left + innerRect.Width; LRight.Y1 = RE.Y1 = innerRect.Margin.Top; LRight.X2 = RE.X2 = innerRect.Margin.Left + innerRect.Width; LRight.Y2 = RE.Y2 = innerRect.Margin.Top + innerRect.Height;
        }
        public override void CtrlsShown(SelectMode PrevMode, SelectMode NewMode)
        {
            switch (NewMode)
            {
                case SelectMode.NON:
                    #region 외곽 숨기기
                    NE.Visibility = Visibility.Hidden;
                    SW.Visibility = Visibility.Hidden;
                    SE.Visibility = Visibility.Hidden;
                    NW.Visibility = Visibility.Hidden;
                    UP.Visibility = Visibility.Hidden;
                    DOWN.Visibility = Visibility.Hidden;
                    LEFT.Visibility = Visibility.Hidden;
                    RIGHT.Visibility = Visibility.Hidden;
                    #endregion
                    #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록 해제
                    

                    if (NW != null)
                    {
                        (NW as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                        (NW as Rectangle).MouseDown -= NWMouseDown;
                        (NW as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (SE != null)
                    {
                        (SE as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                        (SE as Rectangle).MouseDown -= SEMouseDown;
                        (SE as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (UP != null)
                    {
                        (UP as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                        (UP as Rectangle).MouseDown -= UPMouseDown;
                        (UP as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (DOWN != null)
                    {
                        (DOWN as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                        (DOWN as Rectangle).MouseDown -= DOWNMouseDown;
                        (DOWN as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (LEFT != null)
                    {
                        (LEFT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (LEFT as Rectangle).MouseDown -= LEFTMouseDown;
                        (LEFT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (RIGHT != null)
                    {
                        (RIGHT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (RIGHT as Rectangle).MouseDown -= RIGHTMouseDown;
                        (RIGHT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (NE != null)
                    {
                        (NE as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                        (NE as Rectangle).MouseDown -= NEMouseDown;
                        (NE as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (SW != null)
                    {
                        (SW as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                        (SW as Rectangle).MouseDown -= SWMouseDown;
                        (SW as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    #endregion
                    if (innerRect.IsFocused)
                    {
                        //FocusManager.SetFocusedElement(FocusManager.GetFocusScope(MainContent), null);
                        //Keyboard.ClearFocus();
                    }
                    innerRect.Fill = System.Windows.Media.Brushes.Red;
                    break;
                case SelectMode.MOV:
                    //FocusManager.SetFocusedElement(FocusManager.GetFocusScope(MainContent), null);
                    //Keyboard.ClearFocus();
                    switch (PrevMode)
                    {
                        case SelectMode.TXT:
                            break;
                        case SelectMode.NON:
                            #region 외곽 보이기
                            NE.Visibility = Visibility.Visible;
                            SW.Visibility = Visibility.Visible;
                            SE.Visibility = Visibility.Visible;
                            NW.Visibility = Visibility.Visible;
                            UP.Visibility = Visibility.Visible;
                            DOWN.Visibility = Visibility.Visible;
                            LEFT.Visibility = Visibility.Visible;
                            RIGHT.Visibility = Visibility.Visible;
                            RN.Visibility = Visibility.Visible;
                            RE.Visibility = Visibility.Visible;
                            RW.Visibility = Visibility.Visible;
                            RS.Visibility = Visibility.Visible;
                            #endregion
                            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
                            if (LUp != null)
                            {
                                (LUp as Line).MouseEnter += Line_MouseEnter;
                                (LUp as Line).MouseDown += LineMouseDown;
                                (LUp as Line).MouseMove += Movement_Regulator;
                            }
                            if (LDown != null)
                            {
                                (LDown as Line).MouseEnter += Line_MouseEnter;
                                (LDown as Line).MouseDown += LineMouseDown;
                                (LDown as Line).MouseMove += Movement_Regulator;
                            }
                            if (LRight != null)
                            {
                                (LRight as Line).MouseEnter += Line_MouseEnter;
                                (LRight as Line).MouseDown += LineMouseDown;
                                (LRight as Line).MouseMove += Movement_Regulator;
                            }
                            if (LLeft != null)
                            {
                                (LLeft as Line).MouseEnter += Line_MouseEnter;
                                (LLeft as Line).MouseDown += LineMouseDown;
                                (LLeft as Line).MouseMove += Movement_Regulator;
                            }

                            if (NW != null)
                            {
                                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (NW as Rectangle).MouseDown += NWMouseDown;
                                (NW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SE != null)
                            {
                                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (SE as Rectangle).MouseDown += SEMouseDown;
                                (SE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (UP != null)
                            {
                                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (UP as Rectangle).MouseDown += UPMouseDown;
                                (UP as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (DOWN != null)
                            {
                                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                                (DOWN as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (LEFT != null)
                            {
                                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                                (LEFT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (RIGHT != null)
                            {
                                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (NE != null)
                            {
                                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (NE as Rectangle).MouseDown += NEMouseDown;
                                (NE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SW != null)
                            {
                                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (SW as Rectangle).MouseDown += SWMouseDown;
                                (SW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            innerRect.Fill = System.Windows.Media.Brushes.Blue;
                            #endregion
                            break;
                    }
                    break;
                case SelectMode.TXT:
                    
                    
                    break;
            }
        }

        public override void Movement_Regulator(object sender, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed)
            {
                return;
            }
            Thickness newMargin;
            double iw, ih;
            switch (ClickMode)
            {
                case HTarget.LINE:
                    //if (new Rect(ox1 + e.GetPosition(null).X - cpx, oy1 + e.GetPosition(null).Y - cpy, innerRect.Width, innerRect.Height).IntersectsWith(RectToRect(CaptureArea.currentRect))) { return; }
                    newMargin = new Thickness(ox1 + e.GetPosition(null).X - cpx, oy1 + e.GetPosition(null).Y - cpy, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.NW:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    //if (new Rect(ox2 - iw, oy2 - ih, iw, ih).IntersectsWith(RectToRect(CaptureArea.currentRect))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox2 - iw, oy2 - ih, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.UP:
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    //if (new Rect(ox1, oy2 - ih, innerRect.Width, ih).IntersectsWith(RectToRect(CaptureArea.currentRect))) { return; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox1, oy2 - ih, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.NE:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    //if (new Rect(ox1, oy2 - ih, iw, ih).IntersectsWith(RectToRect(CaptureArea.currentRect))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox1, oy2 - ih, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.LEFT:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    //if (new Rect(ox2 - iw, oy1, iw, innerRect.Height).IntersectsWith(RectToRect(CaptureArea.currentRect))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    newMargin = new Thickness(ox2 - iw, oy1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.RIGHT:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    //if (new Rect(innerRect.Margin.Left, innerRect.Margin.Top, iw, innerRect.Height).IntersectsWith(RectToRect(CaptureArea.currentRect))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    break;
                case HTarget.SW:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    //if (new Rect(ox2 - iw, oy1, iw, ih).IntersectsWith(RectToRect(CaptureArea.currentRect))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox2 - iw, oy1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.DOWN:
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    //if (new Rect(innerRect.Margin.Left, innerRect.Margin.Top, innerRect.Width, ih).IntersectsWith(RectToRect(CaptureArea.currentRect))) { return; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    break;
                case HTarget.SE:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    //if (new Rect(innerRect.Margin.Left, innerRect.Margin.Top, iw, ih).IntersectsWith(RectToRect(CaptureArea.currentRect))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    break;

                default:
                    break;
            }
            NW.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top - 5, 0, 0);
            SE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            UP.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top - 5, 0, 0);
            DOWN.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            LEFT.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            NE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top - 5, 0, 0);
            SW.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);

            LUp.X1 = RN.X1 = innerRect.Margin.Left; LUp.Y1 = RN.Y1 = innerRect.Margin.Top; LUp.X2 = RN.X2 = innerRect.Margin.Left + innerRect.Width; LUp.Y2 = RN.Y2 = innerRect.Margin.Top;
            LDown.X1 = RS.X1 = innerRect.Margin.Left; LDown.Y1 = RS.Y1 = innerRect.Margin.Top + innerRect.Height; LDown.X2 = RS.X2 = innerRect.Margin.Left + innerRect.Width; LDown.Y2 = RS.Y2 = innerRect.Margin.Top + innerRect.Height;
            LLeft.X1 = RW.X1 = innerRect.Margin.Left; LLeft.Y1 = RW.Y1 = innerRect.Margin.Top; LLeft.X2 = RW.X2 = innerRect.Margin.Left; LLeft.Y2 = RW.Y2 = innerRect.Margin.Top + innerRect.Height;
            LRight.X1 = RE.X1 = innerRect.Margin.Left + innerRect.Width; LRight.Y1 = RE.Y1 = innerRect.Margin.Top; LRight.X2 = RE.X2 = innerRect.Margin.Left + innerRect.Width; LRight.Y2 = RE.Y2 = innerRect.Margin.Top + innerRect.Height;
        }

        protected override void MainContent_Resize(double x1, double y1, double x2, double y2)
        {
            innerRect.Margin = new Thickness(x1, y1, 0, 0);
            innerRect.Height = y2 - y1; innerRect.Width = x2 - x1;
        }
        #endregion

        #region 구동함수
        //구동함수
        public override void OnApplyTemplate()
        {
            #region 레퍼런스 변수에 각 구성요소 등록
            LUp = Template.FindName("LUp", this) as Line;
            LDown = Template.FindName("LDown", this) as Line;
            LLeft = Template.FindName("LLeft", this) as Line;
            LRight = Template.FindName("LRight", this) as Line;

            innerRect = Template.FindName("innerRect", this) as Rectangle;

            NE = Template.FindName("NE", this) as Rectangle;
            NW = Template.FindName("NW", this) as Rectangle;
            SE = Template.FindName("SE", this) as Rectangle;
            SW = Template.FindName("SW", this) as Rectangle;
            UP = Template.FindName("UP", this) as Rectangle;
            DOWN = Template.FindName("DOWN", this) as Rectangle;
            RIGHT = Template.FindName("RIGHT", this) as Rectangle;
            LEFT = Template.FindName("LEFT", this) as Rectangle;

            RN = Template.FindName("RN", this) as Line;
            RW = Template.FindName("RW", this) as Line;
            RE = Template.FindName("RE", this) as Line;
            RS = Template.FindName("RS", this) as Line;

            #endregion
            this.MouseUp += TxtMouseUp;
            this.MouseLeave += Leave_Regulator;
            //this.LostFocus += TxtLostFocus;
            //this.GotFocus += TxtGainedFocus;
            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
            if (innerRect != null)
            {
                innerRect.MouseDown += LineMouseDown;
                innerRect.MouseMove += Movement_Regulator;
            }
            if (LUp != null)
            {
                (LUp as Line).MouseEnter += Line_MouseEnter;
                (LUp as Line).MouseDown += LineMouseDown;
                (LUp as Line).MouseMove += Movement_Regulator;
            }
            if (LDown != null)
            {
                (LDown as Line).MouseEnter += Line_MouseEnter;
                (LDown as Line).MouseDown += LineMouseDown;
                (LDown as Line).MouseMove += Movement_Regulator;
            }
            if (LRight != null)
            {
                (LRight as Line).MouseEnter += Line_MouseEnter;
                (LRight as Line).MouseDown += LineMouseDown;
                (LRight as Line).MouseMove += Movement_Regulator;
            }
            if (LLeft != null)
            {
                (LLeft as Line).MouseEnter += Line_MouseEnter;
                (LLeft as Line).MouseDown += LineMouseDown;
                (LLeft as Line).MouseMove += Movement_Regulator;
            }

            if (NW != null)
            {
                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (NW as Rectangle).MouseDown += NWMouseDown;
                (NW as Rectangle).MouseMove += Movement_Regulator;
            }
            if (SE != null)
            {
                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (SE as Rectangle).MouseDown += SEMouseDown;
                (SE as Rectangle).MouseMove += Movement_Regulator;
            }
            if (UP != null)
            {
                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (UP as Rectangle).MouseDown += UPMouseDown;
                (UP as Rectangle).MouseMove += Movement_Regulator;
            }
            if (DOWN != null)
            {
                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                (DOWN as Rectangle).MouseMove += Movement_Regulator;
            }
            if (LEFT != null)
            {
                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                (LEFT as Rectangle).MouseMove += Movement_Regulator;
            }
            if (RIGHT != null)
            {
                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
            }
            if (NE != null)
            {
                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (NE as Rectangle).MouseDown += NEMouseDown;
                (NE as Rectangle).MouseMove += Movement_Regulator;
            }
            if (SW != null)
            {
                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (SW as Rectangle).MouseDown += SWMouseDown;
                (SW as Rectangle).MouseMove += Movement_Regulator;
            }
            #endregion

            if (construct) Manual_Relocate(ix1, iy1, ix2, iy2);
            SelVarChange = clickThru.SelectMode.MOV;
            base.OnApplyTemplate();
        }

        public override void InitiateFromPreset(double x1, double y1, double x2, double y2, ControlProperties e)
        {
        }

        protected override void EnforcePreset()
        {
        }
        #endregion


    }
}
