﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using ScreenCoverModule;
using ScreenCoverModule.ScreenControls;
using Underline = ScreenCoverModule.ScreenControls.Underline;

namespace Customcontrols
{
    /// <summary>
    /// Interaction logic for Colorpicker.xaml
    /// </summary>
    public partial class Colorpicker : UserControl
    {
        public Colorpicker()
        {
            InitializeComponent();
        }


        public Brush SelectedColor
        {
            get { return (Brush)GetValue(SelectedColorProperty); }
            set { SetValue(SelectedColorProperty, value);

            }
        }

        // Using a DependencyProperty as the backing store for SelectedColor.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedColorProperty =
            DependencyProperty.Register("SelectedColor", typeof(Brush), typeof(Colorpicker), new UIPropertyMetadata(null));

        private void FontColorBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DependencyObject sp = VisualTreeHelper.GetParent((DependencyObject)e.Source) as UIElement;
            DependencyObject LI = VisualTreeHelper.GetParent(sp) as UIElement;
            DependencyObject t = VisualTreeHelper.GetParent(LI) as UIElement;
            DependencyObject t1 = VisualTreeHelper.GetParent(t) as UIElement;
            DependencyObject t2 = VisualTreeHelper.GetParent(t1) as UIElement;
            DependencyObject t3 = VisualTreeHelper.GetParent(t2) as UIElement;
            DependencyObject t4 = VisualTreeHelper.GetParent(t3) as UIElement;
            DependencyObject t5 = VisualTreeHelper.GetParent(t4) as UIElement;
            DependencyObject t6 = VisualTreeHelper.GetParent(t5) as UIElement;
            DependencyObject t7 = VisualTreeHelper.GetParent(t6) as UIElement;
            MainWindow t8 = t7 as MainWindow;
            if (t8.selection == null) { return; }
            if (t8.selection is NTextBox)
            {
                if ((t8.selection as NTextBox).MainContent != null)
                {
                    ((t8.selection as NTextBox).MainContent.Foreground as SolidColorBrush).Color = (SelectedColor as SolidColorBrush).Color;
                }
            }
            else if (t8.selection is Highlighter)
            {
                if ((t8.selection as Highlighter).outLine != null)
                {
                    if (this.Name == "HColorOutside")
                    {
                        ((t8.selection as Highlighter).outLine.Stroke as SolidColorBrush).Color = (SelectedColor as SolidColorBrush).Color;

                    }
                    else if (this.Name == "HColorInside")
                    {
                        ((t8.selection as Highlighter).outLine.Fill as SolidColorBrush).Color = (SelectedColor as SolidColorBrush).Color;
                    }
                }
            }
            else if (t8.selection is Underline)
            {
                if ((t8.selection as Underline).outLine != null)
                {
                    ((t8.selection as Underline).outLine.Fill as SolidColorBrush).Color = (SelectedColor as SolidColorBrush).Color;

                }

            }

        }
    }
}
