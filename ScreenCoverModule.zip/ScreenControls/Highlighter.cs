﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ScreenCoverModule.ScreenControls
{
    [Serializable()]
    public class Highlighter : Resizables
    {
        public Path outLine;
        public HighlighterProperty presetTemp;
        public Rectangle innerRect;
        public int roundness;
        static Highlighter()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Highlighter), new FrameworkPropertyMetadata(typeof(Highlighter)));
        }
        public void refreshCurveFromInnerRect()
        {
            RectangleGeometry newrp = new RectangleGeometry();
            newrp.Rect = Resizables.RectToRect(innerRect);
            newrp.RadiusX = newrp.RadiusY = Math.Min(newrp.Rect.Width, newrp.Rect.Height) * roundness / 200;

            

            SolidColorBrush outerbrush = new SolidColorBrush((outLine.Stroke as SolidColorBrush).Color);
            outerbrush.Opacity = (outLine.Stroke as SolidColorBrush).Opacity;
            SolidColorBrush innerbrush = new SolidColorBrush((outLine.Fill as SolidColorBrush).Color);
            innerbrush.Opacity = (outLine.Fill as SolidColorBrush).Opacity;

            outLine.Data = newrp;
            outLine.Fill = innerbrush;
            outLine.Stroke = outerbrush;


        }
        #region 추상함수 도입
        public override void InitiateFromPreset(double x1, double y1, double x2, double y2, ControlProperties e)
        {
            presetTemp = e as HighlighterProperty;
            ix1 = x1; iy1 = y1; ix2 = x2; iy2 = y2;
            construct = true;
        }
        protected override void EnforcePreset()
        {
            innerRect.Margin = new Thickness(ix1, iy1, 0, 0);
            innerRect.Height = iy2 - iy1; innerRect.Width = ix2 - ix1;
            NW.Margin = new Thickness(ix1 - 5, iy1 - 5, 0, 0);
            UP.Margin = new Thickness((ix1 + ix2) / 2 - 5, iy1 - 5, 0, 0);
            NE.Margin = new Thickness(ix2 - 5, iy1 - 5, 0, 0);
            LEFT.Margin = new Thickness(ix1 - 5, (iy1 + iy2) / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(ix2 - 5, (iy1 + iy2) / 2 - 5, 0, 0);
            SW.Margin = new Thickness(ix1 - 5, iy2 - 5, 0, 0);
            DOWN.Margin = new Thickness((ix1 + ix2) / 2 - 5, iy2 - 5, 0, 0);
            SE.Margin = new Thickness(ix2 - 5, iy2 - 5, 0, 0);

            RectangleGeometry newrp = new RectangleGeometry();
            newrp.Rect = new Rect(ix1, iy1, ix2 - ix1, iy2 - iy1);
            roundness = presetTemp.Roundness;
            newrp.RadiusX = newrp.RadiusY = Math.Min(newrp.Rect.Width, newrp.Rect.Height) * presetTemp.Roundness / 200;
            SolidColorBrush outerbrush = new SolidColorBrush(presetTemp.outerColor);
            outerbrush.Opacity = presetTemp.outerOpacity;
            SolidColorBrush innerbrush = new SolidColorBrush(presetTemp.innerColor);
            innerbrush.Opacity = presetTemp.innerOpacity;
            outLine.Data = newrp;
            outLine.Fill = innerbrush;
            outLine.Stroke = outerbrush;
            outLine.StrokeThickness = presetTemp.Thick;

        }
        public override void moveByKey(KeyEventArgs e)
        {

            Thickness newMargin;
            switch (e.Key)
            {
                case Key.Up:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(innerRect.Margin.Left, innerRect.Margin.Top - 1, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left, innerRect.Margin.Top - 1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case Key.Down:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(innerRect.Margin.Left, innerRect.Margin.Top + 1, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left, innerRect.Margin.Top + 1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case Key.Left:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(innerRect.Margin.Left - 1, innerRect.Margin.Top, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left - 1, innerRect.Margin.Top, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case Key.Right:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(innerRect.Margin.Left + 1, innerRect.Margin.Top, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left + 1, innerRect.Margin.Top, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                default:
                    return;
            }
            NW.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top - 5, 0, 0);
            SE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            UP.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top - 5, 0, 0);
            DOWN.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            LEFT.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            NE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top - 5, 0, 0);
            SW.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            (outLine.Data as RectangleGeometry).Rect = RectToRect(innerRect);
        }
        public override void CtrlsShown(SelectMode PrevMode, SelectMode NewMode)
        {
            switch (NewMode)
            {
                case SelectMode.NON:
                    #region 외곽 숨기기
                    NE.Visibility = Visibility.Hidden;
                    SW.Visibility = Visibility.Hidden;
                    SE.Visibility = Visibility.Hidden;
                    NW.Visibility = Visibility.Hidden;
                    UP.Visibility = Visibility.Hidden;
                    DOWN.Visibility = Visibility.Hidden;
                    LEFT.Visibility = Visibility.Hidden;
                    RIGHT.Visibility = Visibility.Hidden;
                    #endregion
                    #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록 해제
                    if (NW != null)
                    {
                        (NW as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                        (NW as Rectangle).MouseDown -= NWMouseDown;
                        (NW as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (SE != null)
                    {
                        (SE as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                        (SE as Rectangle).MouseDown -= SEMouseDown;
                        (SE as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (UP != null)
                    {
                        (UP as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                        (UP as Rectangle).MouseDown -= UPMouseDown;
                        (UP as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (DOWN != null)
                    {
                        (DOWN as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                        (DOWN as Rectangle).MouseDown -= DOWNMouseDown;
                        (DOWN as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (LEFT != null)
                    {
                        (LEFT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (LEFT as Rectangle).MouseDown -= LEFTMouseDown;
                        (LEFT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (RIGHT != null)
                    {
                        (RIGHT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (RIGHT as Rectangle).MouseDown -= RIGHTMouseDown;
                        (RIGHT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (NE != null)
                    {
                        (NE as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                        (NE as Rectangle).MouseDown -= NEMouseDown;
                        (NE as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (SW != null)
                    {
                        (SW as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                        (SW as Rectangle).MouseDown -= SWMouseDown;
                        (SW as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    #endregion
                    break;
                case SelectMode.MOV:
                    //FocusManager.SetFocusedElement(FocusManager.GetFocusScope(MainContent), null);
                    //Keyboard.ClearFocus();
                    switch (PrevMode)
                    {
                        case SelectMode.TXT:
                            break;
                        case SelectMode.NON:
                            #region 외곽 보이기
                            NE.Visibility = Visibility.Visible;
                            SW.Visibility = Visibility.Visible;
                            SE.Visibility = Visibility.Visible;
                            NW.Visibility = Visibility.Visible;
                            UP.Visibility = Visibility.Visible;
                            DOWN.Visibility = Visibility.Visible;
                            LEFT.Visibility = Visibility.Visible;
                            RIGHT.Visibility = Visibility.Visible;
                            #endregion
                            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
                            if (LUp != null)
                            {
                                (LUp as Line).MouseEnter += Line_MouseEnter;
                                (LUp as Line).MouseDown += LineMouseDown;
                                (LUp as Line).MouseMove += Movement_Regulator;
                            }
                            if (LDown != null)
                            {
                                (LDown as Line).MouseEnter += Line_MouseEnter;
                                (LDown as Line).MouseDown += LineMouseDown;
                                (LDown as Line).MouseMove += Movement_Regulator;
                            }
                            if (LRight != null)
                            {
                                (LRight as Line).MouseEnter += Line_MouseEnter;
                                (LRight as Line).MouseDown += LineMouseDown;
                                (LRight as Line).MouseMove += Movement_Regulator;
                            }
                            if (LLeft != null)
                            {
                                (LLeft as Line).MouseEnter += Line_MouseEnter;
                                (LLeft as Line).MouseDown += LineMouseDown;
                                (LLeft as Line).MouseMove += Movement_Regulator;
                            }

                            if (NW != null)
                            {
                                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (NW as Rectangle).MouseDown += NWMouseDown;
                                (NW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SE != null)
                            {
                                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (SE as Rectangle).MouseDown += SEMouseDown;
                                (SE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (UP != null)
                            {
                                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (UP as Rectangle).MouseDown += UPMouseDown;
                                (UP as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (DOWN != null)
                            {
                                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                                (DOWN as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (LEFT != null)
                            {
                                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                                (LEFT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (RIGHT != null)
                            {
                                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (NE != null)
                            {
                                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (NE as Rectangle).MouseDown += NEMouseDown;
                                (NE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SW != null)
                            {
                                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (SW as Rectangle).MouseDown += SWMouseDown;
                                (SW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            #endregion
                            break;
                    }
                    break;
                case SelectMode.TXT:
                    break;
            }
        }

        public override void Movement_Regulator(object sender, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed)
            {
                return;
            }
            Thickness newMargin;
            double iw, ih, rx, ry, rw, rh;
            switch (ClickMode)
            {
                case HTarget.LINE:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(ox1 + e.GetPosition(null).X - cpx, oy1 + e.GetPosition(null).Y - cpy, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(ox1 + e.GetPosition(null).X - cpx, oy1 + e.GetPosition(null).Y - cpy, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.NW:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    rx = ox2 - iw; ry = oy2 - ih; rw = iw; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox2 - iw, oy2 - ih, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.UP:
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    rx = ox1; ry = oy2 - ih; rw = innerRect.Width; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox1, oy2 - ih, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.NE:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    rx = ox1; ry = oy2 - ih; rw = iw; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox1, oy2 - ih, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.LEFT:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    rx = ox2 - iw; ry = oy1; rw = iw; rh = innerRect.Height;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    newMargin = new Thickness(ox2 - iw, oy1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.RIGHT:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    rx = innerRect.Margin.Left; ry = innerRect.Margin.Top; rw = iw; rh = innerRect.Height;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    break;
                case HTarget.SW:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    rx = ox2 - iw; ry = oy1; rw = iw; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    newMargin = new Thickness(ox2 - iw, oy1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.DOWN:
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    rx = innerRect.Margin.Left; ry = innerRect.Margin.Top; rw = innerRect.Width; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    break;
                case HTarget.SE:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    rx = innerRect.Margin.Left; ry = innerRect.Margin.Top; rw = iw; rh = ih;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih; } else { ih = 20; }
                    break;

                default:
                    break;
            }
            NW.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top - 5, 0, 0);
            SE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            UP.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top - 5, 0, 0);
            DOWN.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            LEFT.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            NE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top - 5, 0, 0);
            SW.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height - 5, 0, 0);
            refreshCurveFromInnerRect();
            //(outLine.Data as RectangleGeometry).Rect = RectToRect(innerRect);
        }

        protected override void MainContent_Resize(double x1, double y1, double x2, double y2)
        {
            innerRect.Margin = new Thickness(x1, y1, 0, 0);
            innerRect.Height = y2 - y1; innerRect.Width = x2 - x1;
        }
        #endregion
        public override void Manual_Relocate(double x1, double y1, double x2, double y2)
        {
            MainContent_Resize(x1, y1, x2, y2);
            NW.Margin = new Thickness(x1 - 5, y1 - 5, 0, 0);
            UP.Margin = new Thickness((x1 + x2) / 2 - 5, y1 - 5, 0, 0);
            NE.Margin = new Thickness(x2 - 5, y1 - 5, 0, 0);
            LEFT.Margin = new Thickness(x1 - 5, (y1 + y2) / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(x2 - 5, (y1 + y2) / 2 - 5, 0, 0);
            SW.Margin = new Thickness(x1 - 5, y2 - 5, 0, 0);
            DOWN.Margin = new Thickness((x1 + x2) / 2 - 5, y2 - 5, 0, 0);
            SE.Margin = new Thickness(x2 - 5, y2 - 5, 0, 0);
        }
        #region 구동함수
        //구동함수
        public override void OnApplyTemplate()
        {
            #region 레퍼런스 변수에 각 구성요소 등록
            LUp = null;
            LDown = null;
            LLeft = null;
            LRight = null;

            innerRect = Template.FindName("innerRect", this) as Rectangle;

            NE = Template.FindName("NE", this) as Rectangle;
            NW = Template.FindName("NW", this) as Rectangle;
            SE = Template.FindName("SE", this) as Rectangle;
            SW = Template.FindName("SW", this) as Rectangle;
            UP = Template.FindName("UP", this) as Rectangle;
            DOWN = Template.FindName("DOWN", this) as Rectangle;
            RIGHT = Template.FindName("RIGHT", this) as Rectangle;
            LEFT = Template.FindName("LEFT", this) as Rectangle;
            outLine = Template.FindName("outLine", this) as Path;

            RN = null;
            RW = null;
            RE = null;
            RS = null;

            #endregion
            this.MouseUp += TxtMouseUp;
            this.MouseLeave += Leave_Regulator;
            //this.LostFocus += TxtLostFocus;
            //this.GotFocus += TxtGainedFocus;
            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
            if (outLine != null)
            {
                (outLine as Path).MouseMove += Movement_Regulator;
                (outLine as Path).MouseDown += LineMouseDown;
                (outLine as Path).MouseEnter += Line_MouseEnter;
                (outLine as Path).MouseLeave += Leave_Regulator;
            }
            if (innerRect != null)
            {
                (innerRect as Rectangle).MouseMove += Movement_Regulator;
                (innerRect as Rectangle).MouseDown += LineMouseDown;
                (innerRect as Rectangle).MouseEnter += Line_MouseEnter;
                (innerRect as Rectangle).MouseLeave += Leave_Regulator;
            }
            if (NW != null)
            {
                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (NW as Rectangle).MouseDown += NWMouseDown;
                (NW as Rectangle).MouseMove += Movement_Regulator;
            }
            if (SE != null)
            {
                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (SE as Rectangle).MouseDown += SEMouseDown;
                (SE as Rectangle).MouseMove += Movement_Regulator;
            }
            if (UP != null)
            {
                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (UP as Rectangle).MouseDown += UPMouseDown;
                (UP as Rectangle).MouseMove += Movement_Regulator;
            }
            if (DOWN != null)
            {
                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                (DOWN as Rectangle).MouseMove += Movement_Regulator;
            }
            if (LEFT != null)
            {
                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                (LEFT as Rectangle).MouseMove += Movement_Regulator;
            }
            if (RIGHT != null)
            {
                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
            }
            if (NE != null)
            {
                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (NE as Rectangle).MouseDown += NEMouseDown;
                (NE as Rectangle).MouseMove += Movement_Regulator;
            }
            if (SW != null)
            {
                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (SW as Rectangle).MouseDown += SWMouseDown;
                (SW as Rectangle).MouseMove += Movement_Regulator;
            }
            #endregion

            if (construct) EnforcePreset();
            base.OnApplyTemplate();
        }
        #endregion
    }
}
