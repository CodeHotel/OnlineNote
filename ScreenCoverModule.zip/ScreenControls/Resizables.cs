﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;

namespace ScreenCoverModule.ScreenControls
{
    [Serializable]
    public abstract class Resizables : Control
    {
        #region 상태표현 열거형
        public enum HTarget { NE, SW, NW, SE, UP, DOWN, RIGHT, LEFT, LINE, NONE }
        public enum SelectMode { TXT, MOV, NON }
        public HTarget ClickMode = HTarget.NONE;
        protected SelectMode Selected = SelectMode.TXT;
        public SelectMode PreviousSel = SelectMode.TXT;
        #endregion

        #region 벡터계산 중간변수
        protected double ox1;
        protected double oy1;
        protected double ox2;
        protected double oy2;
        protected double cpx;
        protected double cpy;
        protected double ix1;
        protected double ix2;
        protected double iy1;
        protected double iy2;
        protected bool construct = false;
        #endregion

        #region 구성요소 레퍼런스 변수선언
        protected Line LUp;
        protected Line LDown;
        protected Line LRight;
        protected Line LLeft;
        protected Rectangle NE;
        protected Rectangle SW;
        protected Rectangle NW;
        protected Rectangle SE;
        protected Rectangle UP;
        protected Rectangle DOWN;
        protected Rectangle RIGHT;
        protected Rectangle LEFT;
        protected Line RN;
        protected Line RE;
        protected Line RW;
        protected Line RS;
        #endregion

        #region 강제 제원조정함수
        public void init(double x1, double y1, double x2, double y2)
        {
            ix1 = x1; ix2 = x2; iy1 = y1; iy2 = y2; construct = true;
        }
        public virtual void Manual_Relocate(double x1, double y1, double x2, double y2)
        {
            MainContent_Resize(x1, y1, x2, y2);
            NW.Margin = new Thickness(x1 - 5, y1 - 5, 0, 0);
            UP.Margin = new Thickness((x1 + x2) / 2 - 5, y1 - 5, 0, 0);
            NE.Margin = new Thickness(x2 - 5, y1 - 5, 0, 0);
            LEFT.Margin = new Thickness(x1 - 5, (y1 + y2) / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(x2 - 5, (y1 + y2) / 2 - 5, 0, 0);
            SW.Margin = new Thickness(x1 - 5, y2 - 5, 0, 0);
            DOWN.Margin = new Thickness((x1 + x2) / 2 - 5, y2 - 5, 0, 0);
            SE.Margin = new Thickness(x2 - 5, y2 - 5, 0, 0);

            LUp.X1 = RN.X1 = x1; LUp.X2 = RN.X2 = x2; LUp.Y1 = LUp.Y2 = RN.Y1 = RN.Y2 = y1;
            LDown.X1 = RS.X1 = x1; LDown.X2 = RS.X2 = x2; LDown.Y1 = LDown.Y2 = RS.Y1 = RS.Y2 = y2;
            LLeft.X1 = LLeft.X2 = RW.X1 = RW.X2 = x1; LLeft.Y1 = RW.Y1 = y1; LLeft.Y2 = RW.Y2 = y2;
            LRight.X1 = LRight.X2 = RE.X1 = RE.X2 = x2; LRight.Y1 = RE.Y1 = y1; LRight.Y2 = RE.Y2 = y2;
        }
        protected abstract void MainContent_Resize(double x1, double y1, double x2, double y2);
        #endregion

        #region mousehover 관련 이벤트처리함수
        protected void Leave_Regulator(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && ClickMode != HTarget.NONE)
            {
                Movement_Regulator(sender, e);
            }
            else
            {
                ClickMode = HTarget.NONE;
                Cursor = Cursors.Arrow;
            }
        }
        protected void Square_MouseEnter_NWSE(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.SizeNWSE;
        }
        protected void Line_MouseEnter(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.SizeAll;
        }
        protected void Square_MouseEnter_NESW(object sender, EventArgs e)
        {
            Cursor = Cursors.SizeNESW;
        }
        protected void Square_MouseEnter_NS(object sender, EventArgs e)
        {
            Cursor = Cursors.SizeNS;
        }
        protected void Square_MouseEnter_WE(object sender, EventArgs e)
        {
            Cursor = Cursors.SizeWE;
        }
        #endregion

        #region 핸들 및 윤곽선 표시/숨기기
        public SelectMode SelVarChange
        {
            get { return Selected; }
            set
            {
                if (value != Selected)
                {
                    PreviousSel = Selected;
                    Selected = value;
                    CtrlsShown(PreviousSel, Selected);
                }
            }
        }

        public abstract void CtrlsShown(SelectMode PrevMode, SelectMode NewMode);

        public abstract void InitiateFromPreset(double x1, double y1, double x2, double y2, ControlProperties e);
        protected abstract void EnforcePreset();
        #endregion

        #region MouseDown함수
        protected virtual void LineMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.LINE;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;
            ox1 = NW.Margin.Left + 5;
            oy1 = NW.Margin.Top + 5;
        }

        protected void NEMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.NE;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = NW.Margin.Left + 5;
            oy1 = NW.Margin.Top + 5;

            ox2 = ox1 + NE.Margin.Left - NW.Margin.Left;
            oy2 = oy1 + SW.Margin.Top - NW.Margin.Top;

        }
        protected void SEMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.SE;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = NW.Margin.Left + 5;
            oy1 = NW.Margin.Top + 5;

            ox2 = ox1 + NE.Margin.Left - NW.Margin.Left;
            oy2 = oy1 + SW.Margin.Top - NW.Margin.Top;

        }
        protected void NWMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.NW;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = NW.Margin.Left + 5;
            oy1 = NW.Margin.Top + 5;

            ox2 = ox1 + NE.Margin.Left - NW.Margin.Left;
            oy2 = oy1 + SW.Margin.Top - NW.Margin.Top;

        }
        protected void SWMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.SW;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = NW.Margin.Left + 5;
            oy1 = NW.Margin.Top + 5;

            ox2 = ox1 + NE.Margin.Left - NW.Margin.Left;
            oy2 = oy1 + SW.Margin.Top - NW.Margin.Top;

        }
        protected void UPMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.UP;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = NW.Margin.Left + 5;
            oy1 = NW.Margin.Top + 5;

            ox2 = ox1 + NE.Margin.Left - NW.Margin.Left;
            oy2 = oy1 + SW.Margin.Top - NW.Margin.Top;

        }
        protected void DOWNMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.DOWN;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = NW.Margin.Left + 5;
            oy1 = NW.Margin.Top + 5;

            ox2 = ox1 + NE.Margin.Left - NW.Margin.Left;
            oy2 = oy1 + SW.Margin.Top - NW.Margin.Top;

        }
        protected virtual void LEFTMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.LEFT;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = NW.Margin.Left + 5;
            oy1 = NW.Margin.Top + 5;

            ox2 = ox1 + NE.Margin.Left - NW.Margin.Left;
            oy2 = oy1 + SW.Margin.Top - NW.Margin.Top;

        }
        protected virtual void RIGHTMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.RIGHT;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = NW.Margin.Left + 5;
            oy1 = NW.Margin.Top + 5;

            ox2 = ox1 + NE.Margin.Left - NW.Margin.Left;
            oy2 = oy1 + SW.Margin.Top - NW.Margin.Top;

        }
        #endregion

        #region 크기조정 이벤트처리함수
        public abstract void Movement_Regulator(object sender, MouseEventArgs e);
        public abstract void moveByKey(KeyEventArgs e);
        #endregion

        //MouseUp 이벤트 처리함수
        public void TxtMouseUp(object sender, MouseEventArgs e)
        {
            if (ClickMode == HTarget.UP)
            {
                Movement_Regulator(sender, e);
            }
            ClickMode = HTarget.NONE;
        }

        public static Rect RectToRect(Rectangle r)
        {
            return new Rect(r.Margin.Left, r.Margin.Top, r.Width, r.Height);
        }
        public static Rect CutRect(Rect knife, Rect Cake, bool inside)
        {
            if (!knife.IntersectsWith(Cake))
            {
                return Cake;
            }
            else if (inside)
            {
                Cake.Intersect(knife);
                return Cake;
            }
            else
            {
                Rect tempCake = new Rect(Cake.X, Cake.Y, Cake.Width, Cake.Height);
                Rect tempCake2 = new Rect(Cake.X, Cake.Y, Cake.Width, Cake.Height);
                Cake.Intersect(knife);
                
                if (Cake.X > tempCake.X)
                {
                    tempCake.X = tempCake2.X + tempCake2.Width - Cake.Width;
                }
                tempCake.Width = tempCake2.Width - Cake.Width;

                if (Cake.Y > tempCake.Y)
                {
                    tempCake.Y = tempCake2.Y + tempCake2.Height - Cake.Height;
                }
                tempCake.Height = tempCake2.Height - Cake.Height;
                return tempCake;
            }
        }
    }
}
