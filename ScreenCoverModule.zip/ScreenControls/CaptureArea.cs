﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;

namespace ScreenCoverModule.ScreenControls
{
    [Serializable()]
    public class CaptureArea : Resizables
    {
        public static Rectangle currentRect;
        public Rectangle innerRect;
        bool LOCKED = false;

        static CaptureArea()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CaptureArea), new FrameworkPropertyMetadata(typeof(CaptureArea)));
        }

        #region 추상함수 도입
        public override void moveByKey(KeyEventArgs e)
        {

        }
        public CaptureArea clone()
        {
            return (CaptureArea)this.MemberwiseClone();
        }
        public void LOCK()
        {
            if (LOCKED) { return; }
            
            if (NE == null || SW == null || SE == null || NW == null || UP == null || UP == null || DOWN == null || LEFT == null || RIGHT == null)
            {
                return;
            }
            LOCKED = true;
            if (LUp != null)
            {
                (LUp as Line).MouseEnter -= Line_MouseEnter;
                (LUp as Line).MouseDown -= LineMouseDown;
                (LUp as Line).MouseMove -= Movement_Regulator;
                (LUp as Line).MouseLeave -= Leave_Regulator;
            }
            if (LDown != null)
            {
                (LDown as Line).MouseEnter -= Line_MouseEnter;
                (LDown as Line).MouseDown -= LineMouseDown;
                (LDown as Line).MouseMove -= Movement_Regulator;
                (LDown as Line).MouseLeave -= Leave_Regulator;
            }
            if (LRight != null)
            {
                (LRight as Line).MouseEnter -= Line_MouseEnter;
                (LRight as Line).MouseDown -= LineMouseDown;
                (LRight as Line).MouseMove -= Movement_Regulator;
                (LRight as Line).MouseLeave -= Leave_Regulator;
            }
            if (LLeft != null)
            {
                (LLeft as Line).MouseEnter -= Line_MouseEnter;
                (LLeft as Line).MouseDown -= LineMouseDown;
                (LLeft as Line).MouseMove -= Movement_Regulator;
                (LLeft as Line).MouseLeave -= Leave_Regulator;
            }
            NE.Visibility = Visibility.Hidden;
            SW.Visibility = Visibility.Hidden;
            SE.Visibility = Visibility.Hidden;
            NW.Visibility = Visibility.Hidden;
            UP.Visibility = Visibility.Hidden;
            DOWN.Visibility = Visibility.Hidden;
            LEFT.Visibility = Visibility.Hidden;
            RIGHT.Visibility = Visibility.Hidden;
            if (NW != null)
            {
                (NW as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                (NW as Rectangle).MouseDown -= NWMouseDown;
                (NW as Rectangle).MouseMove -= Movement_Regulator;
            }
            if (SE != null)
            {
                (SE as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                (SE as Rectangle).MouseDown -= SEMouseDown;
                (SE as Rectangle).MouseMove -= Movement_Regulator;
            }
            if (UP != null)
            {
                (UP as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                (UP as Rectangle).MouseDown -= UPMouseDown;
                (UP as Rectangle).MouseMove -= Movement_Regulator;
            }
            if (DOWN != null)
            {
                (DOWN as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                (DOWN as Rectangle).MouseDown -= DOWNMouseDown;
                (DOWN as Rectangle).MouseMove -= Movement_Regulator;
            }
            if (LEFT != null)
            {
                (LEFT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                (LEFT as Rectangle).MouseDown -= LEFTMouseDown;
                (LEFT as Rectangle).MouseMove -= Movement_Regulator;
            }
            if (RIGHT != null)
            {
                (RIGHT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                (RIGHT as Rectangle).MouseDown -= RIGHTMouseDown;
                (RIGHT as Rectangle).MouseMove -= Movement_Regulator;
            }
            if (NE != null)
            {
                (NE as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                (NE as Rectangle).MouseDown -= NEMouseDown;
                (NE as Rectangle).MouseMove -= Movement_Regulator;
            }
            if (SW != null)
            {
                (SW as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                (SW as Rectangle).MouseDown -= SWMouseDown;
                (SW as Rectangle).MouseMove -= Movement_Regulator;
            }
        }
        public void UNLOCK()
        {
            if (!LOCKED) { return; }
            if (NE == null || SW == null || SE == null || NW == null || UP == null || UP == null || DOWN == null || LEFT == null || RIGHT == null)
            {
                return;
            }
            LOCKED = false;
            if (LUp != null)
            {
                (LUp as Line).MouseEnter += Line_MouseEnter;
                (LUp as Line).MouseDown += LineMouseDown;
                (LUp as Line).MouseMove += Movement_Regulator;
                (LUp as Line).MouseLeave += Leave_Regulator;
            }
            if (LDown != null)
            {
                (LDown as Line).MouseEnter += Line_MouseEnter;
                (LDown as Line).MouseDown += LineMouseDown;
                (LDown as Line).MouseMove += Movement_Regulator;
                (LDown as Line).MouseLeave += Leave_Regulator;
            }
            if (LRight != null)
            {
                (LRight as Line).MouseEnter += Line_MouseEnter;
                (LRight as Line).MouseDown += LineMouseDown;
                (LRight as Line).MouseMove += Movement_Regulator;
                (LRight as Line).MouseLeave += Leave_Regulator;
            }
            if (LLeft != null)
            {
                (LLeft as Line).MouseEnter += Line_MouseEnter;
                (LLeft as Line).MouseDown += LineMouseDown;
                (LLeft as Line).MouseMove += Movement_Regulator;
                (LLeft as Line).MouseLeave += Leave_Regulator;
            }
            NE.Visibility = Visibility.Visible;
            SW.Visibility = Visibility.Visible;
            SE.Visibility = Visibility.Visible;
            NW.Visibility = Visibility.Visible;
            UP.Visibility = Visibility.Visible;
            DOWN.Visibility = Visibility.Visible;
            LEFT.Visibility = Visibility.Visible;
            RIGHT.Visibility = Visibility.Visible;
            if (NW != null)
            {
                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (NW as Rectangle).MouseDown += NWMouseDown;
                (NW as Rectangle).MouseMove += Movement_Regulator;
            }
            if (SE != null)
            {
                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (SE as Rectangle).MouseDown += SEMouseDown;
                (SE as Rectangle).MouseMove += Movement_Regulator;
            }
            if (UP != null)
            {
                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (UP as Rectangle).MouseDown += UPMouseDown;
                (UP as Rectangle).MouseMove += Movement_Regulator;
            }
            if (DOWN != null)
            {
                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                (DOWN as Rectangle).MouseMove += Movement_Regulator;
            }
            if (LEFT != null)
            {
                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                (LEFT as Rectangle).MouseMove += Movement_Regulator;
            }
            if (RIGHT != null)
            {
                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
            }
            if (NE != null)
            {
                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (NE as Rectangle).MouseDown += NEMouseDown;
                (NE as Rectangle).MouseMove += Movement_Regulator;
            }
            if (SW != null)
            {
                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (SW as Rectangle).MouseDown += SWMouseDown;
                (SW as Rectangle).MouseMove += Movement_Regulator;
            }
        }
        public override void CtrlsShown(SelectMode PrevMode, SelectMode NewMode)
        {
            switch (NewMode)
            {
                case SelectMode.NON:
                    #region 외곽 숨기기
                    NE.Visibility = Visibility.Hidden;
                    SW.Visibility = Visibility.Hidden;
                    SE.Visibility = Visibility.Hidden;
                    NW.Visibility = Visibility.Hidden;
                    UP.Visibility = Visibility.Hidden;
                    DOWN.Visibility = Visibility.Hidden;
                    LEFT.Visibility = Visibility.Hidden;
                    RIGHT.Visibility = Visibility.Hidden;
                    #endregion
                    #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록 해제


                    if (NW != null)
                    {
                        (NW as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                        (NW as Rectangle).MouseDown -= NWMouseDown;
                        (NW as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (SE != null)
                    {
                        (SE as Rectangle).MouseEnter -= Square_MouseEnter_NWSE;
                        (SE as Rectangle).MouseDown -= SEMouseDown;
                        (SE as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (UP != null)
                    {
                        (UP as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                        (UP as Rectangle).MouseDown -= UPMouseDown;
                        (UP as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (DOWN != null)
                    {
                        (DOWN as Rectangle).MouseEnter -= Square_MouseEnter_NS;
                        (DOWN as Rectangle).MouseDown -= DOWNMouseDown;
                        (DOWN as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (LEFT != null)
                    {
                        (LEFT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (LEFT as Rectangle).MouseDown -= LEFTMouseDown;
                        (LEFT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (RIGHT != null)
                    {
                        (RIGHT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (RIGHT as Rectangle).MouseDown -= RIGHTMouseDown;
                        (RIGHT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (NE != null)
                    {
                        (NE as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                        (NE as Rectangle).MouseDown -= NEMouseDown;
                        (NE as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (SW != null)
                    {
                        (SW as Rectangle).MouseEnter -= Square_MouseEnter_NESW;
                        (SW as Rectangle).MouseDown -= SWMouseDown;
                        (SW as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    #endregion
                    if (innerRect.IsFocused)
                    {
                        //FocusManager.SetFocusedElement(FocusManager.GetFocusScope(MainContent), null);
                        //Keyboard.ClearFocus();
                    }
                    break;
                case SelectMode.MOV:
                    //FocusManager.SetFocusedElement(FocusManager.GetFocusScope(MainContent), null);
                    //Keyboard.ClearFocus();
                    switch (PrevMode)
                    {
                        case SelectMode.TXT:
                            break;
                        case SelectMode.NON:
                            #region 외곽 보이기
                            NE.Visibility = Visibility.Visible;
                            SW.Visibility = Visibility.Visible;
                            SE.Visibility = Visibility.Visible;
                            NW.Visibility = Visibility.Visible;
                            UP.Visibility = Visibility.Visible;
                            DOWN.Visibility = Visibility.Visible;
                            LEFT.Visibility = Visibility.Visible;
                            RIGHT.Visibility = Visibility.Visible;
                            RN.Visibility = Visibility.Visible;
                            RE.Visibility = Visibility.Visible;
                            RW.Visibility = Visibility.Visible;
                            RS.Visibility = Visibility.Visible;
                            #endregion
                            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
                            if (NW != null)
                            {
                                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (NW as Rectangle).MouseDown += NWMouseDown;
                                (NW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SE != null)
                            {
                                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                                (SE as Rectangle).MouseDown += SEMouseDown;
                                (SE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (UP != null)
                            {
                                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (UP as Rectangle).MouseDown += UPMouseDown;
                                (UP as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (DOWN != null)
                            {
                                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                                (DOWN as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (LEFT != null)
                            {
                                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                                (LEFT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (RIGHT != null)
                            {
                                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (NE != null)
                            {
                                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (NE as Rectangle).MouseDown += NEMouseDown;
                                (NE as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (SW != null)
                            {
                                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                                (SW as Rectangle).MouseDown += SWMouseDown;
                                (SW as Rectangle).MouseMove += Movement_Regulator;
                            }
                            #endregion
                            break;
                    }
                    break;
                case SelectMode.TXT:


                    break;
            }
        }

        public override void Movement_Regulator(object sender, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed)
            {
                return;
            }
            Thickness newMargin;
            double iw, ih;
            switch (ClickMode)
            {
                case HTarget.LINE:
                    newMargin = new Thickness(ox1 + e.GetPosition(null).X - cpx + 5, oy1 + e.GetPosition(null).Y - cpy + 5, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.NW:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    if (iw >= 20) { innerRect.Width = iw - 10; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih - 10; } else { ih = 20; }
                    newMargin = new Thickness(ox2 - iw + 5, oy2 - ih + 5, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.UP:
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    if (ih >= 20) { innerRect.Height = ih - 10; } else { ih = 20; }
                    newMargin = new Thickness(ox1 + 5, oy2 - ih + 5, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.NE:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    ih = oy2 - oy1 - e.GetPosition(null).Y + cpy;
                    if (iw >= 20) { innerRect.Width = iw - 10; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih - 10; } else { ih = 20; }
                    newMargin = new Thickness(ox1 + 5, oy2 - ih + 5, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.LEFT:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    if (iw >= 20) { innerRect.Width = iw - 10; } else { iw = 20; }
                    newMargin = new Thickness(ox2 - iw + 5, oy1 + 5, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.RIGHT:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    if (iw >= 20) { innerRect.Width = iw - 10; } else { iw = 20; }
                    break;
                case HTarget.SW:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    if (iw >= 20) { innerRect.Width = iw - 10; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih - 10; } else { ih = 20; }
                    newMargin = new Thickness(ox2 - iw + 5, oy1 + 5, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.DOWN:
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    if (ih >= 20) { innerRect.Height = ih - 10; } else { ih = 20; }
                    break;
                case HTarget.SE:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    ih = oy2 - oy1 + e.GetPosition(null).Y - cpy;
                    if (iw >= 20) { innerRect.Width = iw - 10; } else { iw = 20; }
                    if (ih >= 20) { innerRect.Height = ih - 10; } else { ih = 20; }
                    break;

                default:
                    break;
            }
            NW.Margin = new Thickness(innerRect.Margin.Left - 10, innerRect.Margin.Top - 10, 0, 0);
            SE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width, innerRect.Margin.Top + innerRect.Height, 0, 0);
            UP.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top - 10, 0, 0);
            DOWN.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width / 2 - 5, innerRect.Margin.Top + innerRect.Height, 0, 0);
            LEFT.Margin = new Thickness(innerRect.Margin.Left - 10, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            NE.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width, innerRect.Margin.Top - 10, 0, 0);
            SW.Margin = new Thickness(innerRect.Margin.Left - 10, innerRect.Margin.Top + innerRect.Height, 0, 0);

            LUp.X1 = RN.X1 = innerRect.Margin.Left - 5; LUp.Y1 = RN.Y1 = innerRect.Margin.Top - 5; LUp.X2 = RN.X2 = innerRect.Margin.Left + innerRect.Width + 5; LUp.Y2 = RN.Y2 = innerRect.Margin.Top - 5;
            LDown.X1 = RS.X1 = innerRect.Margin.Left - 5; LDown.Y1 = RS.Y1 = innerRect.Margin.Top + innerRect.Height + 5; LDown.X2 = RS.X2 = innerRect.Margin.Left + innerRect.Width + 5; LDown.Y2 = RS.Y2 = innerRect.Margin.Top + innerRect.Height + 5;
            LLeft.X1 = RW.X1 = innerRect.Margin.Left - 5; LLeft.Y1 = RW.Y1 = innerRect.Margin.Top - 5; LLeft.X2 = RW.X2 = innerRect.Margin.Left - 5; LLeft.Y2 = RW.Y2 = innerRect.Margin.Top + innerRect.Height + 5;
            LRight.X1 = RE.X1 = innerRect.Margin.Left + innerRect.Width + 5; LRight.Y1 = RE.Y1 = innerRect.Margin.Top - 5; LRight.X2 = RE.X2 = innerRect.Margin.Left + innerRect.Width + 5; LRight.Y2 = RE.Y2 = innerRect.Margin.Top + innerRect.Height + 5;

            currentRect = innerRect;
            DependencyObject sp = System.Windows.Media.VisualTreeHelper.GetParent(NW) as UIElement;
            DependencyObject LI = System.Windows.Media.VisualTreeHelper.GetParent(sp) as UIElement;
            DependencyObject t = System.Windows.Media.VisualTreeHelper.GetParent(LI) as UIElement;
            DependencyObject mw = System.Windows.Media.VisualTreeHelper.GetParent(t) as UIElement;
            DependencyObject mw1 = System.Windows.Media.VisualTreeHelper.GetParent(mw) as UIElement;
            DependencyObject mw2 = System.Windows.Media.VisualTreeHelper.GetParent(mw1) as UIElement;
            DependencyObject mw3 = System.Windows.Media.VisualTreeHelper.GetParent(mw2) as UIElement;
            if ((mw3 as MainWindow).currentPage != null)
            {
                (mw3 as MainWindow).currentPage.PageArea = this;
            }
            else
            {
                (mw3 as MainWindow).RecordArea = this;
            }
        }

        protected override void MainContent_Resize(double x1, double y1, double x2, double y2)
        {
            innerRect.Margin = new Thickness(x1 + 5, y1 + 5, 0, 0);
            innerRect.Height = y2 - y1 - 10; innerRect.Width = x2 - x1 - 10;
            currentRect = innerRect;
        }
        #endregion

        #region 구동함수
        //구동함수
        public override void OnApplyTemplate()
        {
            #region 레퍼런스 변수에 각 구성요소 등록
            LUp = Template.FindName("LUp", this) as Line;
            LDown = Template.FindName("LDown", this) as Line;
            LLeft = Template.FindName("LLeft", this) as Line;
            LRight = Template.FindName("LRight", this) as Line;

            innerRect = Template.FindName("innerRect", this) as Rectangle;

            NE = Template.FindName("NE", this) as Rectangle;
            NW = Template.FindName("NW", this) as Rectangle;
            SE = Template.FindName("SE", this) as Rectangle;
            SW = Template.FindName("SW", this) as Rectangle;
            UP = Template.FindName("UP", this) as Rectangle;
            DOWN = Template.FindName("DOWN", this) as Rectangle;
            RIGHT = Template.FindName("RIGHT", this) as Rectangle;
            LEFT = Template.FindName("LEFT", this) as Rectangle;

            RN = Template.FindName("RN", this) as Line;
            RW = Template.FindName("RW", this) as Line;
            RE = Template.FindName("RE", this) as Line;
            RS = Template.FindName("RS", this) as Line;

            #endregion
            this.MouseUp += TxtMouseUp;
            this.MouseLeave += Leave_Regulator;
            //this.LostFocus += TxtLostFocus;
            //this.GotFocus += TxtGainedFocus;
            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
            if (LUp != null)
            {
                (LUp as Line).MouseEnter += Line_MouseEnter;
                (LUp as Line).MouseDown += LineMouseDown;
                (LUp as Line).MouseMove += Movement_Regulator;
                (LUp as Line).MouseLeave += Leave_Regulator;
            }
            if (LDown != null)
            {
                (LDown as Line).MouseEnter += Line_MouseEnter;
                (LDown as Line).MouseDown += LineMouseDown;
                (LDown as Line).MouseMove += Movement_Regulator;
                (LDown as Line).MouseLeave += Leave_Regulator;
            }
            if (LRight != null)
            {
                (LRight as Line).MouseEnter += Line_MouseEnter;
                (LRight as Line).MouseDown += LineMouseDown;
                (LRight as Line).MouseMove += Movement_Regulator;
                (LRight as Line).MouseLeave += Leave_Regulator;
            }
            if (LLeft != null)
            {
                (LLeft as Line).MouseEnter += Line_MouseEnter;
                (LLeft as Line).MouseDown += LineMouseDown;
                (LLeft as Line).MouseMove += Movement_Regulator;
                (LLeft as Line).MouseLeave += Leave_Regulator;
            }

            if (NW != null)
            {
                (NW as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (NW as Rectangle).MouseDown += NWMouseDown;
                (NW as Rectangle).MouseMove += Movement_Regulator;
                (NW as Rectangle).MouseLeave += Leave_Regulator;
            }
            if (SE != null)
            {
                (SE as Rectangle).MouseEnter += Square_MouseEnter_NWSE;
                (SE as Rectangle).MouseDown += SEMouseDown;
                (SE as Rectangle).MouseMove += Movement_Regulator;
                (SE as Rectangle).MouseLeave += Leave_Regulator;
            }
            if (UP != null)
            {
                (UP as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (UP as Rectangle).MouseDown += UPMouseDown;
                (UP as Rectangle).MouseMove += Movement_Regulator;
                (UP as Rectangle).MouseLeave += Leave_Regulator;
            }
            if (DOWN != null)
            {
                (DOWN as Rectangle).MouseEnter += Square_MouseEnter_NS;
                (DOWN as Rectangle).MouseDown += DOWNMouseDown;
                (DOWN as Rectangle).MouseMove += Movement_Regulator;
                (DOWN as Rectangle).MouseLeave += Leave_Regulator;
            }
            if (LEFT != null)
            {
                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                (LEFT as Rectangle).MouseMove += Movement_Regulator;
                (LEFT as Rectangle).MouseLeave += Leave_Regulator;
            }
            if (RIGHT != null)
            {
                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
                (RIGHT as Rectangle).MouseLeave += Leave_Regulator;
            }
            if (NE != null)
            {
                (NE as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (NE as Rectangle).MouseDown += NEMouseDown;
                (NE as Rectangle).MouseMove += Movement_Regulator;
                (NE as Rectangle).MouseLeave += Leave_Regulator;
            }
            if (SW != null)
            {
                (SW as Rectangle).MouseEnter += Square_MouseEnter_NESW;
                (SW as Rectangle).MouseDown += SWMouseDown;
                (SW as Rectangle).MouseMove += Movement_Regulator;
                (SW as Rectangle).MouseLeave += Leave_Regulator;
            }
            #endregion

            if (construct) Manual_Relocate(ix1, iy1, ix2, iy2);
            SelVarChange = CaptureArea.SelectMode.MOV;

            base.OnApplyTemplate();
        }

        public override void InitiateFromPreset(double x1, double y1, double x2, double y2, ControlProperties e)
        {
        }

        protected override void EnforcePreset()
        {
        }
        #endregion


    }
}
