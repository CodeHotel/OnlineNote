﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ScreenCoverModule.ScreenControls
{
    [Serializable()]
    public class Underline : Resizables
    {
        public Rectangle innerRect;
        public Path outLine;
        public UnderlineProperty presetTemp;
        public int roundness;

        static Underline()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Underline), new FrameworkPropertyMetadata(typeof(Underline)));
        }

        public override void InitiateFromPreset(double x1, double y1, double x2, double y2, ControlProperties e)
        {
            presetTemp = e as UnderlineProperty;
            ix1 = x1; iy1 = y1; ix2 = x2; iy2 = y1 + presetTemp.Thick;
            construct = true;
        }

        protected override void EnforcePreset()
        {
            MainContent_Resize(ix1, iy1, ix2, iy2);
            LEFT.Margin = new Thickness(ix1 - 5, (iy1 + iy2) / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(ix2 - 5, (iy1 + iy2) / 2 - 5, 0, 0);
            RectangleGeometry newrp = new RectangleGeometry();
            newrp.Rect = new Rect(ix1, iy1, ix2 - ix1, iy2 - iy1);
            newrp.RadiusX = newrp.RadiusY = Math.Min(newrp.Rect.Width, newrp.Rect.Height) * presetTemp.Roundness / 200;
            outLine.Data = newrp;
            outLine.Fill = new SolidColorBrush(presetTemp.lineColor); outLine.StrokeThickness = 0;
            roundness = presetTemp.Roundness;
        }

        public void refreshCurveFromInnerRect()
        {
            RectangleGeometry newrp = new RectangleGeometry();
            newrp.Rect = Resizables.RectToRect(innerRect);
            newrp.RadiusX = newrp.RadiusY = Math.Min(newrp.Rect.Width, newrp.Rect.Height) * roundness / 200;

            outLine.Data = newrp;

            LEFT.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
        }

        #region 추상함수 도입
        public override void moveByKey(KeyEventArgs e)
        {
            Thickness newMargin;
            switch (e.Key)
            {
                case Key.Up:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(innerRect.Margin.Left, innerRect.Margin.Top - 1, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left, innerRect.Margin.Top - 1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case Key.Down:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(innerRect.Margin.Left, innerRect.Margin.Top + 1, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left, innerRect.Margin.Top + 1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case Key.Left:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(innerRect.Margin.Left - 1, innerRect.Margin.Top, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left - 1, innerRect.Margin.Top, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case Key.Right:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(innerRect.Margin.Left + 1, innerRect.Margin.Top, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(innerRect.Margin.Left + 1, innerRect.Margin.Top, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                default:
                    return;
            }
            LEFT.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            (outLine.Data as RectangleGeometry).Rect = RectToRect(innerRect);
        }
        public override void CtrlsShown(SelectMode PrevMode, SelectMode NewMode)
        {
            switch (NewMode)
            {
                case SelectMode.NON:
                    #region 외곽 숨기기
                    LEFT.Visibility = Visibility.Hidden;
                    RIGHT.Visibility = Visibility.Hidden;
                    #endregion
                    #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록 해제
                    if (LEFT != null)
                    {
                        (LEFT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (LEFT as Rectangle).MouseDown -= LEFTMouseDown;
                        (LEFT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    if (RIGHT != null)
                    {
                        (RIGHT as Rectangle).MouseEnter -= Square_MouseEnter_WE;
                        (RIGHT as Rectangle).MouseDown -= RIGHTMouseDown;
                        (RIGHT as Rectangle).MouseMove -= Movement_Regulator;
                    }
                    #endregion
                    break;
                case SelectMode.MOV:
                    //FocusManager.SetFocusedElement(FocusManager.GetFocusScope(MainContent), null);
                    //Keyboard.ClearFocus();
                    switch (PrevMode)
                    {
                        case SelectMode.TXT:
                            break;
                        case SelectMode.NON:
                            #region 외곽 보이기
                            LEFT.Visibility = Visibility.Visible;
                            RIGHT.Visibility = Visibility.Visible;
                            #endregion
                            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
                            if (LEFT != null)
                            {
                                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                                (LEFT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            if (RIGHT != null)
                            {
                                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
                            }
                            #endregion
                            break;
                    }
                    break;
                case SelectMode.TXT:
                    break;
            }
        }

        public override void Movement_Regulator(object sender, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed)
            {
                return;
            }
            Thickness newMargin;
            double iw, ih, rx, ry, rw, rh;
            switch (ClickMode)
            {
                case HTarget.LINE:
                    if (!RectToRect(CaptureArea.currentRect).Contains(new Rect(ox1 + e.GetPosition(null).X - cpx, oy1 + e.GetPosition(null).Y - cpy, innerRect.Width, innerRect.Height))) { return; }
                    newMargin = new Thickness(ox1 + e.GetPosition(null).X - cpx, oy1 + e.GetPosition(null).Y - cpy, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.LEFT:
                    iw = ox2 - ox1 - e.GetPosition(null).X + cpx;
                    rx = ox2 - iw; ry = oy1; rw = iw; rh = innerRect.Height;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    newMargin = new Thickness(ox2 - iw, oy1, 0, 0);
                    innerRect.Margin = newMargin;
                    break;
                case HTarget.RIGHT:
                    iw = ox2 - ox1 + e.GetPosition(null).X - cpx;
                    rx = innerRect.Margin.Left; ry = innerRect.Margin.Top; rw = iw; rh = innerRect.Height;
                    if (rx < 0) { rx = 1; }
                    if (ry < 0) { ry = 1; }
                    if (rw < 20) { rw = 20; }
                    if (rh < 20) { rh = 20; }
                    if (!(RectToRect(CaptureArea.currentRect).Contains(new Rect(rx, ry, rw, rh)))) { return; }
                    if (iw >= 20) { innerRect.Width = iw; } else { iw = 20; }
                    break;
                default:
                    break;
            }
            LEFT.Margin = new Thickness(innerRect.Margin.Left - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            RIGHT.Margin = new Thickness(innerRect.Margin.Left + innerRect.Width - 5, innerRect.Margin.Top + innerRect.Height / 2 - 5, 0, 0);
            (outLine.Data as RectangleGeometry).Rect = RectToRect(innerRect);
        }
        protected override void LEFTMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.LEFT;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = innerRect.Margin.Left;
            oy1 = innerRect.Margin.Top;

            ox2 = innerRect.Margin.Left + innerRect.Width;
            oy2 = innerRect.Margin.Top + innerRect.Height;

        }
        protected override void RIGHTMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.RIGHT;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;

            ox1 = innerRect.Margin.Left;
            oy1 = innerRect.Margin.Top;

            ox2 = innerRect.Margin.Left + innerRect.Width;
            oy2 = innerRect.Margin.Top + innerRect.Height;

        }
        protected override void LineMouseDown(object sender, MouseEventArgs e)
        {
            SelVarChange = SelectMode.MOV;
            ClickMode = HTarget.LINE;
            cpx = e.GetPosition(null).X;
            cpy = e.GetPosition(null).Y;
            ox1 = innerRect.Margin.Left;
            oy1 = innerRect.Margin.Top;
        }
        protected override void MainContent_Resize(double x1, double y1, double x2, double y2)
        {
            innerRect.Margin = new Thickness(x1, y1, 0, 0);
            innerRect.Height = y2 - y1; innerRect.Width = x2 - x1;
        }
        #endregion

        #region 구동함수
        //구동함수
        public override void OnApplyTemplate()
        {
            #region 레퍼런스 변수에 각 구성요소 등록
            LUp = Template.FindName("LUp", this) as Line;
            LDown = Template.FindName("LDown", this) as Line;
            LLeft = Template.FindName("LLeft", this) as Line;
            LRight = Template.FindName("LRight", this) as Line;

            innerRect = Template.FindName("innerRect", this) as Rectangle;
            outLine = Template.FindName("outLine", this) as Path;
            NE = Template.FindName("NE", this) as Rectangle;
            NW = Template.FindName("NW", this) as Rectangle;
            SE = Template.FindName("SE", this) as Rectangle;
            SW = Template.FindName("SW", this) as Rectangle;
            UP = Template.FindName("UP", this) as Rectangle;
            DOWN = Template.FindName("DOWN", this) as Rectangle;
            RIGHT = Template.FindName("RIGHT", this) as Rectangle;
            LEFT = Template.FindName("LEFT", this) as Rectangle;

            RN = Template.FindName("RN", this) as Line;
            RW = Template.FindName("RW", this) as Line;
            RE = Template.FindName("RE", this) as Line;
            RS = Template.FindName("RS", this) as Line;

            #endregion
            this.MouseUp += TxtMouseUp;
            this.MouseLeave += Leave_Regulator;
            //this.LostFocus += TxtLostFocus;
            //this.GotFocus += TxtGainedFocus;
            #region 각 구성요소 이벤트 델리게이트에 이벤트 처리기 등록
            if (outLine != null)
            {
                (outLine as Path).MouseMove += Movement_Regulator;
                (outLine as Path).MouseDown += LineMouseDown;
                (outLine as Path).MouseEnter += Line_MouseEnter;
                (outLine as Path).MouseLeave += Leave_Regulator;
            }
            if (LEFT != null)
            {
                (LEFT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (LEFT as Rectangle).MouseDown += LEFTMouseDown;
                (LEFT as Rectangle).MouseMove += Movement_Regulator;
            }
            if (RIGHT != null)
            {
                (RIGHT as Rectangle).MouseEnter += Square_MouseEnter_WE;
                (RIGHT as Rectangle).MouseDown += RIGHTMouseDown;
                (RIGHT as Rectangle).MouseMove += Movement_Regulator;
            }

            #endregion

            if (construct) EnforcePreset();
            base.OnApplyTemplate();
        }


        #endregion
    }
}
