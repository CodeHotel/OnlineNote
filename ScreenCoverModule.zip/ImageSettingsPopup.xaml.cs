﻿using ScreenCoverModule.ScreenControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ScreenCoverModule
{
    /// <summary>
    /// Interaction logic for ImageSettingsPopup.xaml
    /// </summary>
    public partial class ImageSettingsPopup : Window
    {
        public static BitmapSource bitClipBoard;
        private MainWindow ParentReference;
        private NotePage TargetPage;
        public List<BitmapSource> imgsToDelete = new List<BitmapSource>();
        public ImageSettingsPopup(MainWindow pref, NotePage targetPage)
        {
            InitializeComponent();
            ListBoxItem tempitem;
            ParentReference = pref;
            TargetPage = targetPage;
            for (int i = 0; i < targetPage.candidateImages.Count; i++)
            {
                tempitem = BoxItemFromImage(targetPage.candidateImages[i]);
                ImagesList.Items.Add(tempitem);

            }
            if (targetPage.candidateImages.Count != 0)
            {
                ImagesList.SelectedItem = ImagesList.Items[targetPage.MainCandidateImageIndex];
            }
        }

        public ImageSettingsPopup()
        {
            InitializeComponent();

        }

        private void PagesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int newselectedimageno = ImagesList.Items.IndexOf(ImagesList.SelectedItem);
            if (newselectedimageno == -1) { return; }
            StackPanel np = ((ListBoxItem)(ParentReference.PagesList.Items[ParentReference.notePages.IndexOf(TargetPage)])).Content as StackPanel;
            if (np == null) { return; }
            Image ni = null;
            for (int i = 0; i < np.Children.Count; i++)
            {
                if (np.Children[i] is Image)
                {
                    ni = np.Children[i] as Image;
                }
            }
            if (ni == null) { return; }
            ni.Source = TargetPage.candidateImages[newselectedimageno];
            TargetPage.MainCandidateImageIndex = newselectedimageno;
            if (ParentReference.backGroundImgShown)
            {
                CaptureArea.currentRect.Fill = new ImageBrush(TargetPage.candidateImages[TargetPage.MainCandidateImageIndex]);
            }
        }
        private void deleteListItem(object sender, RoutedEventArgs e)
        {
            DependencyObject sp = VisualTreeHelper.GetParent((DependencyObject)e.Source) as UIElement;
            DependencyObject LI = VisualTreeHelper.GetParent(sp) as UIElement;
            DependencyObject t = VisualTreeHelper.GetParent(LI) as UIElement;
            DependencyObject t1 = VisualTreeHelper.GetParent(t) as UIElement;
            int myt = ImagesList.Items.IndexOf(t1);
            /*if (myt == TargetPage.candidateImages.IndexOf(currentPage))
            {
                clearScreenOfPage();
            }*/
            TargetPage.candidateImages.Remove(TargetPage.candidateImages[myt]);
            ImagesList.Items.Remove(ImagesList.Items[myt]);
            if (ImagesList.Items.Count == 0) 
            {
                StackPanel np = ((ListBoxItem)(ParentReference.PagesList.SelectedItem)).Content as StackPanel;
                if (np == null) { return; }
                Image ni = null;
                for (int i = 0; i < np.Children.Count; i++)
                {
                    if (np.Children[i] is Image)
                    {
                        ni = np.Children[i] as Image;
                    }
                }
                if (ni == null) { return; }
                ni.Source = new BitmapImage(new Uri(@"/icos/icon_img.png", UriKind.Relative));
                TargetPage.MainCandidateImageIndex = 0;
                CaptureArea.currentRect.Fill = Brushes.Transparent;
            }
            else if (myt == ImagesList.Items.Count)
            {
                ImagesList.SelectedItem = ImagesList.Items[myt - 1];
            }
            else
            {
                ImagesList.SelectedItem = ImagesList.Items[myt];
            }
            
        }
        private ListBoxItem BoxItemFromImage(BitmapSource e)
        {
            ListBoxItem tmpbox = new ListBoxItem();
            StackPanel nPanel = new StackPanel();
            Image nImage = new Image();
            Button DelBtn = new Button();

            nPanel.Name = "nPanel";
            nImage.Name = "nImage";
            DelBtn.Name = "DelBtn";

            nPanel.Orientation = Orientation.Horizontal;
            DelBtn.Margin = new Thickness(20, 0, 0, 0);
            DelBtn.Width = DelBtn.Height = 20;
            DelBtn.Background = Brushes.Transparent;
            Image TrashIcon = new Image();
            TrashIcon.Source = new BitmapImage(new Uri(@"/icos/icon_Trash.png", UriKind.Relative));
            DelBtn.Content = TrashIcon;
            DelBtn.BorderBrush = Brushes.Transparent; DelBtn.IsEnabled = true;
            DelBtn.Click += deleteListItem;

            nImage.Source = e;
            nImage.Width = 60; nImage.Height = 45;
            nImage.IsEnabled = true; nImage.HorizontalAlignment = HorizontalAlignment.Left;
            nImage.VerticalAlignment = VerticalAlignment.Top;
            nImage.Stretch = Stretch.Uniform;

            nPanel.Children.Add(nImage);
            nPanel.Children.Add(DelBtn);
            tmpbox.Content = nPanel;
            return tmpbox;
        }

        private void Copy_Click(object sender, RoutedEventArgs e)
        {
            int newselectedimageno = ImagesList.Items.IndexOf(ImagesList.SelectedItem);
            if (newselectedimageno == -1) { return; }
            bitClipBoard = TargetPage.candidateImages[newselectedimageno];
        }

        private void Paste_Click(object sender, RoutedEventArgs e)
        {
            if (bitClipBoard == null) { return; }
            TargetPage.candidateImages.Add(bitClipBoard);
            ImagesList.Items.Add(BoxItemFromImage(bitClipBoard));
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape) { Close(); }
        }
    }
}
