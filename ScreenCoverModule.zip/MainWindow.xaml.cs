﻿using ScreenCoverModule.ScreenControls;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Underline = ScreenCoverModule.ScreenControls.Underline;
using PdfSharp.Pdf;
using PdfSharp.Drawing;

namespace ScreenCoverModule
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        savefile tempsav;
        private bool isToolMoving = false;
        private Point ToolOriginalPoint;
        private Point ToolOriginalVector;
        public List<NotePage> notePages;
        private Resizables selTmp = null;
        public List<Color> colorref;
        private static readonly System.Text.RegularExpressions.Regex _regex = new System.Text.RegularExpressions.Regex("[^0-9.-]+"); //regex that matches disallowed text
        System.Drawing.Bitmap tempbmp;
        private static bool IsTextAllowed(string text)
        {
            return !_regex.IsMatch(text);
        }
        public Resizables selection
        {
            get
            {
                return selTmp;
            }
            set
            {
                if (selTmp != value)
                {
                    selTmp = value;
                    int t1; int t2 = 0; double d1;
                    TextOptions.Visibility = Visibility.Hidden;
                    HighOptions.Visibility = Visibility.Hidden;
                    UOptions.Visibility = Visibility.Hidden;
                    if (selTmp is NTextBox)
                    {
                        TextOptions.Visibility = Visibility.Visible;
                        if ((selTmp as NTextBox).MainContent == null)
                        {
                            t1 = listFont.IndexOf((selTmp as NTextBox).presetTemp.FontType.ToString());
                            d1 = (selTmp as NTextBox).presetTemp.FontSize;
                            t2 = findColorIndex((selTmp as NTextBox).presetTemp.TextColor);
                            FontColorBox.FontColorBox.SelectedItem = FontColorBox.FontColorBox.Items[t2];
                            if ((selTmp as NTextBox).presetTemp.Italic) { ItaBtn.BorderBrush = Brushes.DarkCyan; }
                            else { ItaBtn.BorderBrush = Brushes.Transparent; }

                            if ((selTmp as NTextBox).presetTemp.Bold) { BoldBtn.BorderBrush = Brushes.DarkCyan; }
                            else { BoldBtn.BorderBrush = Brushes.Transparent; }
                            //FontColorBox.SelectedColor = Brushes.Red;
                        }
                        else
                        {
                            t1 = listFont.IndexOf((selTmp as NTextBox).MainContent.FontFamily.ToString());
                            d1 = (selTmp as NTextBox).MainContent.FontSize;
                            t2 = findColorIndex(((selTmp as NTextBox).MainContent.Foreground as SolidColorBrush).Color);
                            FontColorBox.FontColorBox.SelectedItem = FontColorBox.FontColorBox.Items[t2];
                            if ((selTmp as NTextBox).MainContent.FontWeight == FontWeights.Bold)
                            {
                                BoldBtn.BorderBrush = Brushes.DarkCyan;
                            }
                            else { BoldBtn.BorderBrush = Brushes.Transparent; }

                            if ((selTmp as NTextBox).MainContent.FontStyle == FontStyles.Italic)
                            {
                                ItaBtn.BorderBrush = Brushes.DarkCyan;
                            }
                            else { ItaBtn.BorderBrush = Brushes.Transparent; }
                        }

                        if (t1 != -1)
                        {
                            cbxFont.SelectedItem = cbxFont.Items[t1];
                        }
                        FontSizeBox.Text = d1.ToString();

                    }
                    if (selTmp is Highlighter)
                    {
                        HighOptions.Visibility = Visibility.Visible;
                        if ((selTmp as Highlighter).outLine == null)
                        {
                            t2 = findColorIndex((selTmp as Highlighter).presetTemp.innerColor);
                            HColorInside.FontColorBox.SelectedItem = HColorInside.FontColorBox.Items[t2];
                            t2 = findColorIndex((selTmp as Highlighter).presetTemp.outerColor);
                            HColorOutside.FontColorBox.SelectedItem = HColorOutside.FontColorBox.Items[t2];
                            d1 = (selTmp as Highlighter).presetTemp.innerOpacity;
                            innerOp.Text = d1.ToString();
                            d1 = (selTmp as Highlighter).presetTemp.outerOpacity;
                            outerOp.Text = d1.ToString();
                            d1 = (selTmp as Highlighter).presetTemp.Thick;
                            HighThickBox.Text = d1.ToString();
                            d1 = (selTmp as Highlighter).presetTemp.Roundness;
                            HighRoundBox.Text = d1.ToString();

                        }
                        else
                        {
                            t2 = findColorIndex(((selTmp as Highlighter).outLine.Fill as SolidColorBrush).Color);
                            HColorInside.FontColorBox.SelectedItem = HColorInside.FontColorBox.Items[t2];
                            t2 = findColorIndex(((selTmp as Highlighter).outLine.Stroke as SolidColorBrush).Color);
                            HColorOutside.FontColorBox.SelectedItem = HColorOutside.FontColorBox.Items[t2];
                            d1 = ((selTmp as Highlighter).outLine.Fill as SolidColorBrush).Opacity;
                            innerOp.Text = d1.ToString();
                            d1 = ((selTmp as Highlighter).outLine.Stroke as SolidColorBrush).Opacity;
                            outerOp.Text = d1.ToString();
                            d1 = (selTmp as Highlighter).outLine.StrokeThickness;
                            HighThickBox.Text = d1.ToString();
                            t1 = (selTmp as Highlighter).roundness;
                            HighRoundBox.Text = t1.ToString();
                        }

                    }
                    if (selTmp is ScreenControls.Underline)
                    {
                        UOptions.Visibility = Visibility.Visible;
                        if ((selTmp as Underline).outLine == null)
                        {
                            t2 = findColorIndex((selTmp as Underline).presetTemp.lineColor);
                            UColorInside.FontColorBox.SelectedItem = UColorInside.FontColorBox.Items[t2];
                            d1 = (selTmp as Underline).presetTemp.Thick;
                            UThickBox.Text = d1.ToString();
                            t1 = (selTmp as Underline).presetTemp.Roundness;
                            URoundBox.Text = t1.ToString();

                        }
                        else
                        {
                            t2 = findColorIndex(((selTmp as Underline).outLine.Fill as SolidColorBrush).Color);
                            UColorInside.FontColorBox.SelectedItem = UColorInside.FontColorBox.Items[t2];
                            d1 = (selTmp as Underline).innerRect.Height;
                            UThickBox.Text = d1.ToString();
                            t1 = (selTmp as Underline).roundness;
                            URoundBox.Text = t1.ToString();
                        }

                    }

                }
            }
        }
        
        private int selectionType = -1;
        private bool Through = false;
        public double dpiX = 1;
        public double dpiY = 1;
        public double DpiScaleX = 25565; public double DpiScaleY = 25565;
        public CaptureArea RecordArea;
        private Thread globalMouseListener;
        private Thread captureThread;
        private int recordtime = 5;
        public enum ControlType { TextBox, Highlighter, Underline, PunchThru }
        public enum circularSelect { N, W, S, E, Center }
        private circularSelect CDirection;
        double tempx1 = 0; double tempx2 = 20; double tempy1 = 0; double tempy2 = 20;
        SubjectSettings.TypesOfCtrls CreatingCtrl = SubjectSettings.TypesOfCtrls.NONE;
        bool CircularMenu = false;
        bool mouseListenerPause = false;
        SubjectSettings currentSettings;
        public NotePage currentPage;
        bool isTempRect = false;
        bool bgshown = false;
        bool firststart = true;
        BitmapSource queueImg;
        BitmapSource tempImg;
        Grid PingGrid;
        public List<String> listFont;
        public bool backGroundImgShown
        {
            get
            {
                return bgshown;
            }
            set
            {
                bgshown = value;
                if (bgshown)
                {
                    (HideorShow.Content as Image).Source = new BitmapImage(new Uri(@"/icos/icon_Hide.png", UriKind.Relative));
                }
                else
                {
                    (HideorShow.Content as Image).Source = new BitmapImage(new Uri(@"/icos/icon_img.png", UriKind.Relative));
                }
            }
        }
        bool record = false;
        private int findColorIndex(Color e)
        {
            System.Reflection.PropertyInfo[] t = typeof(Colors).GetProperties();
            for (int i = 0; i < t.Length; i++)
            {
                if (FromColor(e) == t[i]) { return i; }
            }
            return -1;
        }

        System.Reflection.PropertyInfo FromColor(Color c)
        {
            var type = typeof(Colors);
            var res = type.GetProperties(System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public)
                .Where(p => p.GetValue(null, null).ToString() == c.ToString()) // is there another way?
                .Select(p => p).FirstOrDefault();
            return res;
        }
        public bool isRecording
        {
            get
            {
                return record;
            }
            set
            {
                record = value;
                if (record)
                {
                    (Record.Content as Image).Source = new BitmapImage(new Uri(@"/icos/icon_stop.png", UriKind.Relative));
                }
                else
                {
                    (Record.Content as Image).Source = new BitmapImage(new Uri(@"/icos/icon_Rec.png", UriKind.Relative));
                }
            }
        }
        Point Circularpos;
        Rectangle temprect;
        BitmapImage cN;
        BitmapImage cW;
        BitmapImage cE;
        BitmapImage cS;
        BitmapImage cM;
        BitmapSource suggestion;
        #region MouseThru
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetCursorPos(ref Win32Point pt);

        [StructLayout(LayoutKind.Sequential)]
        internal struct Win32Point
        {
            public Int32 X;
            public Int32 Y;
        };

        public static Point GetMousePosition()
        {
            Win32Point w32Mouse = new Win32Point();
            GetCursorPos(ref w32Mouse);
            return new Point(w32Mouse.X, w32Mouse.Y);
        }
        public const int WS_EX_TRANSPARENT = 0x00000020; public const int GWL_EXSTYLE = (-20);
        public const int exclude = 0x00000011;

        [DllImport("user32.dll")]
        public static extern int GetWindowLong(IntPtr hwnd, int index);

        [DllImport("user32.dll")]
        public static extern int SetWindowLong(IntPtr hwnd, int index, int newStyle);

        
        private void MouseThru(bool Thru)
        {
            // Get this window's handle         
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            // Change the extended window style to include WS_EX_TRANSPARENT         
            int extendedStyle = GetWindowLong(hwnd, GWL_EXSTYLE);

            if (Thru)
            {
                SetWindowLong(hwnd, GWL_EXSTYLE, extendedStyle | WS_EX_TRANSPARENT);
            }
            else
            {
                SetWindowLong(hwnd, GWL_EXSTYLE, extendedStyle & ~WS_EX_TRANSPARENT);
            }
            Through = Thru;
        }
        #endregion

        #region 메인 윈도우 생성자
        public MainWindow()
        {
            InitializeComponent();

            #region 페이지 초기화(로드)
            notePages = new List<NotePage>();
            #endregion

            #region 과목설정 초기화(로드)
            currentSettings = new SubjectSettings();
            PingGrid = PingImgFromSettings(currentSettings);
            #endregion

            #region 녹화영역 초기화
            RecordArea = new CaptureArea();
            RecordArea.init(currentSettings.RecordArea.X, currentSettings.RecordArea.Y, currentSettings.RecordArea.X + currentSettings.RecordArea.Width, currentSettings.RecordArea.Y + currentSettings.RecordArea.Height);
            MainGrid.Children.Add(RecordArea);

            #endregion

            #region 리소스 초기화
            cM = new BitmapImage(new Uri(@"/icos/main_72DPI.png", UriKind.Relative));
            cN = new BitmapImage(new Uri(@"/icos/N_72ppi.png", UriKind.Relative));
            cW = new BitmapImage(new Uri(@"/icos/W_72ppi.png", UriKind.Relative));
            cS = new BitmapImage(new Uri(@"/icos/S_72ppi.png", UriKind.Relative));
            cE = new BitmapImage(new Uri(@"/icos/E_75Dpi.png", UriKind.Relative));
            #endregion
            
            var cond = System.Windows.Markup.XmlLanguage.GetLanguage
        (System.Globalization.CultureInfo.CurrentUICulture.Name);

            listFont = new List<string>();
            foreach (FontFamily font in Fonts.SystemFontFamilies)
            {
                if (font.FamilyNames.ContainsKey(cond))
                    listFont.Add(font.FamilyNames[cond]);
                else
                    listFont.Add(font.ToString());
            }

            listFont.Sort();

            cbxFont.ItemsSource = listFont;



            #region MouseThruListener
            globalMouseListener = new Thread(() =>
            {
                while (true)
                {
                    while (mouseListenerPause)
                    {

                    }
                    Point p1 = GetMousePosition();
                    bool mouseInControl = false;
                    if (DpiScaleX == 25565 || DpiScaleY == 25565) { continue; }
                    p1.X = p1.X / DpiScaleX;
                    p1.Y = p1.Y / DpiScaleY;

                    Dispatcher.BeginInvoke(new Action(() =>
                    {

                        for (int i = 0; i < currentSettings.Punches.Count; i++)
                        {
                            if (currentSettings.Punches[i].innerRect == null) { continue; }
                            if (currentSettings.Punches[i].SelVarChange == Resizables.SelectMode.MOV) { continue; }
                            Point p2 = new Point();
                            Rect r = new Rect();
                            p2 = currentSettings.Punches[i].innerRect.TransformToAncestor(this).Transform(new Point(0, 0));
                            r.X = p2.X + this.Left + 5;
                            r.Y = p2.Y + this.Top + 5;
                            r.Width = currentSettings.Punches[i].innerRect.Width - 10;
                            r.Height = currentSettings.Punches[i].innerRect.Height - 10;
                            if (r.Contains(p1))
                            {
                                mouseInControl = mouseInControl || true;
                            }
                        }


                        if (mouseInControl && !Through)
                        {
                            Cursor = Cursors.Arrow;
                            MouseThru(true);
                        }
                        else if (!mouseInControl && Through)
                        {
                            MouseThru(false);
                        }
                    }));


                    Thread.Sleep(5);
                }
            });

            globalMouseListener.Start();

            #endregion

            captureThread = new Thread(() =>
            {
                while (true)
                {
                    while (!isRecording) { }
                    Dispatcher.BeginInvoke(new Action(async () =>
                    {
                        if (isRecording)
                        {
                            tempImg = null;
                            await sccap(RecordArea.innerRect);
                            if (notePages.Count != 0 && currentPage != null && currentPage.candidateImages.Count != 0 && currentPage.candidateImages[currentPage.MainCandidateImageIndex] != null)
                            {
                                int tmpcomp = comparebitmaps(currentPage.candidateImages[currentPage.MainCandidateImageIndex], tempImg, currentSettings.imgDivision);
                                //Debug.WriteLine("l: "+tmpcomp);
                                if (tmpcomp > currentSettings.imgTolerance)
                                {
                                    Suggest(tempImg);
                                }
                            }
                            else
                            {
                                Suggest(tempImg);
                            }

                        }

                    }));


                    Thread.Sleep(1000 * recordtime);
                }
            });

            captureThread.Start();

            BrandNewPage();
        }
        public MainWindow(String FilePath)
        {
            InitializeComponent();

            #region 페이지 초기화(로드)
            notePages = new List<NotePage>();
            #endregion

            #region 과목설정 초기화(로드)
            currentSettings = new SubjectSettings();
            #endregion

            #region 녹화영역 초기화
            RecordArea = new CaptureArea();
            MainGrid.Children.Add(RecordArea);
            RecordArea.init(70, 70, 300, 300);
            #endregion

            #region 리소스 초기화
            cM = new BitmapImage(new Uri(@"/icos/main_72DPI.png", UriKind.Relative));
            cN = new BitmapImage(new Uri(@"/icos/N_72ppi.png", UriKind.Relative));
            cW = new BitmapImage(new Uri(@"/icos/W_72ppi.png", UriKind.Relative));
            cS = new BitmapImage(new Uri(@"/icos/S_72ppi.png", UriKind.Relative));
            cE = new BitmapImage(new Uri(@"/icos/E_75Dpi.png", UriKind.Relative));
            #endregion

            #region MouseThruListener
            globalMouseListener = new Thread(() =>
            {
                while (true)
                {
                    Point p1 = GetMousePosition();
                    bool mouseInControl = false;
                    if (DpiScaleX == 25565 || DpiScaleY == 25565) { continue; }
                    p1.X = p1.X / DpiScaleX;
                    p1.Y = p1.Y / DpiScaleY;

                    Dispatcher.BeginInvoke(new Action(() =>
                    {

                        for (int i = 0; i < currentSettings.Punches.Count; i++)
                        {
                            if (currentSettings.Punches[i].innerRect == null) { continue; }
                            if (currentSettings.Punches[i].SelVarChange == Resizables.SelectMode.MOV) { continue; }
                            Point p2 = new Point();
                            Rect r = new Rect();
                            p2 = currentSettings.Punches[i].innerRect.TransformToAncestor(this).Transform(new Point(0, 0));
                            r.X = p2.X + this.Left + 5;
                            r.Y = p2.Y + this.Top + 5;
                            r.Width = currentSettings.Punches[i].innerRect.Width - 10;
                            r.Height = currentSettings.Punches[i].innerRect.Height - 10;
                            if (r.Contains(p1))
                            {
                                mouseInControl = mouseInControl || true;
                            }
                        }


                        if (mouseInControl && !Through)
                        {
                            Cursor = Cursors.Arrow;
                            MouseThru(true);
                        }
                        else if (!mouseInControl && Through)
                        {
                            MouseThru(false);
                        }
                    }));


                    Thread.Sleep(5);
                }
            });

            globalMouseListener.Start();
            #endregion
        }
        #endregion

        #region 페이지리스트 관련 함수
        private void BrandNewPage()
        {
            NotePage nNotePage = new NotePage();
            nNotePage.PageArea = new CaptureArea();
            if (firststart)
            {
                nNotePage.PageArea.init(70, 70, 300, 300);
                firststart = false;
            }
            else
            {
                nNotePage.PageArea.init(RecordArea.innerRect.Margin.Left-5, RecordArea.innerRect.Margin.Top-5, RecordArea.innerRect.Margin.Left + RecordArea.innerRect.Width+5, RecordArea.innerRect.Margin.Top + RecordArea.innerRect.Height+5);
            }
            notePages.Add(nNotePage);
            ListBoxItem tempt = BoxItemFromPage(nNotePage);
            PagesList.Items.Add(tempt);
            PagesList.SelectedItem = tempt;
            //PagesList.UpdateLayout();
            //PagesList.SelectedItem = nItem;

        }

        private void Suggest(BitmapSource e)
        {
            SuggestYes.Visibility = Visibility.Visible;
            SuggestNo.Visibility = Visibility.Visible;
            SuggestHmm.Visibility = Visibility.Visible;
            SuggestRect.Fill = Brushes.OrangeRed;
            ImageBrush newBrush = new ImageBrush(e);
            newBrush.Stretch = Stretch.Uniform;
            SuggestionImg.Fill = newBrush;
            queueImg = e;
        }

        private void SuggestYesClick(object sender, RoutedEventArgs e)
        {
            SuggestYes.Visibility = Visibility.Hidden;
            SuggestNo.Visibility = Visibility.Hidden;
            SuggestHmm.Visibility = Visibility.Hidden;
            SuggestRect.Fill = Brushes.LightGreen;
            SuggestionImg.Fill = Brushes.Transparent;

            PageFromCapture(queueImg);
        }
        private void SuggestHmmClick(object sender, RoutedEventArgs e)
        {
            SuggestYes.Visibility = Visibility.Hidden;
            SuggestNo.Visibility = Visibility.Hidden;
            SuggestHmm.Visibility = Visibility.Hidden;
            SuggestRect.Fill = Brushes.LightGreen;
            SuggestionImg.Fill = Brushes.Transparent;

            if (PagesList.Items.Count == 0) { return; }
            StackPanel np = ((ListBoxItem)(PagesList.SelectedItem)).Content as StackPanel;
            if (np == null) { return; }
            Image ni = null;
            for (int i = 0; i < np.Children.Count; i++)
            {
                if (np.Children[i] is Image)
                {
                    ni = np.Children[i] as Image;
                }
            }
            if (ni == null) { return; }

            currentPage.candidateImages.Add(queueImg);
            if (currentPage.candidateImages.Count == 1)
            {
                currentPage.MainCandidateImageIndex = currentPage.candidateImages.IndexOf(queueImg);

                ni.Source = queueImg;
            }
        }

        private void SuggestNoClick(object sender, RoutedEventArgs e)
        {
            SuggestYes.Visibility = Visibility.Hidden;
            SuggestNo.Visibility = Visibility.Hidden;
            SuggestHmm.Visibility = Visibility.Hidden;
            SuggestRect.Fill = Brushes.LightGreen;
            SuggestionImg.Fill = Brushes.Transparent;
        }

        private void StopCapture()
        {

        }

        private void BeginCapture()
        {

        }

        private void PageFromCapture(BitmapSource e)
        {

            NotePage nNotePage = new NotePage();
            nNotePage.PageArea = new CaptureArea();
            nNotePage.PageArea.init(RecordArea.innerRect.Margin.Left - 5, RecordArea.innerRect.Margin.Top - 5, RecordArea.innerRect.Margin.Left + RecordArea.innerRect.Width + 5, RecordArea.innerRect.Margin.Top + RecordArea.innerRect.Height + 5);
            notePages.Add(nNotePage);
            nNotePage.candidateImages.Add(e);
            ListBoxItem tempt = BoxItemFromPage(nNotePage);
            PagesList.Items.Add(tempt);
            PagesList.SelectedItem = tempt;
        }

        private ListBoxItem BoxItemFromPage(NotePage e)
        {
            ListBoxItem tmpbox = new ListBoxItem();
            StackPanel nPanel = new StackPanel();
            Image nImage = new Image();
            Button ImgBtn = new Button();
            Button DelBtn = new Button();

            nPanel.Name = "nPanel";
            nImage.Name = "nImage";
            ImgBtn.Name = "ImgBtn";
            DelBtn.Name = "DelBtn";

            nPanel.Orientation = Orientation.Horizontal;
            ImgBtn.Margin = new Thickness(12, 0, 0, 0);
            ImgBtn.Width = ImgBtn.Height = 30;
            ImgBtn.Background = Brushes.Transparent;
            Image imgicon = new Image();
            imgicon.Source = new BitmapImage(new Uri(@"/icos/icon_img.png", UriKind.Relative));
            ImgBtn.Content = imgicon;
            ImgBtn.BorderBrush = Brushes.Transparent;
            ImgBtn.Click += editImageList;

            DelBtn.Margin = new Thickness(17, 0, 0, 0);
            DelBtn.Width = DelBtn.Height = 30;
            DelBtn.Background = Brushes.Transparent;
            Image TrashIcon = new Image();
            TrashIcon.Source = new BitmapImage(new Uri(@"/icos/icon_Trash.png", UriKind.Relative));
            DelBtn.Content = TrashIcon;
            DelBtn.BorderBrush = Brushes.Transparent; DelBtn.IsEnabled = true;
            DelBtn.Click += deleteListItem;

            if (e.candidateImages.Count != 0)
            {
                nImage.Source = e.candidateImages[e.MainCandidateImageIndex];
            }
            else
            {
                nImage.Source = new BitmapImage(new Uri(@"/icos/icon_img.png", UriKind.Relative));
            }
            nImage.Width = 60; nImage.Height = 45;
            nImage.IsEnabled = true; nImage.HorizontalAlignment = HorizontalAlignment.Left;
            nImage.VerticalAlignment = VerticalAlignment.Top;
            nImage.Stretch = Stretch.Uniform;

            nPanel.Children.Add(nImage);
            nPanel.Children.Add(ImgBtn);
            nPanel.Children.Add(DelBtn);
            tmpbox.Content = nPanel;
            return tmpbox;
        }

        /*            <ListBoxItem>
                <StackPanel Orientation="Horizontal">
                    <Image Source="/icos/icon_img.png" Width="60" Height="45"/>
                    <Button HorizontalAlignment="Left" Margin="20,0,0,0" VerticalAlignment="Center" Width="20" Height="20" BorderBrush="Transparent" Background="Transparent">
                        <Image Source="/icos/icon_img.png" IsEnabled="True"/>
                    </Button>
                    <Button HorizontalAlignment="Left" Margin="20,0,0,0" VerticalAlignment="Center" Width="20" Height="20" Click="deleteListItem"/>
                </StackPanel>
            </ListBoxItem>*/
        private void editImageList(object sender, RoutedEventArgs e)
        {
            DependencyObject sp = VisualTreeHelper.GetParent((DependencyObject)e.Source) as UIElement;
            DependencyObject LI = VisualTreeHelper.GetParent(sp) as UIElement;
            DependencyObject t = VisualTreeHelper.GetParent(LI) as UIElement;
            DependencyObject t1 = VisualTreeHelper.GetParent(t) as UIElement;
            int myt = PagesList.Items.IndexOf(t1);
            isRecording = false;

            ImageSettingsPopup mywin = new ImageSettingsPopup(this, notePages[myt]);
            mywin.ShowDialog();
        }
        private void deleteListItem(object sender, RoutedEventArgs e)
        {
            DependencyObject sp = VisualTreeHelper.GetParent((DependencyObject)e.Source) as UIElement;
            DependencyObject LI = VisualTreeHelper.GetParent(sp) as UIElement;
            DependencyObject t = VisualTreeHelper.GetParent(LI) as UIElement;
            DependencyObject t1 = VisualTreeHelper.GetParent(t) as UIElement;
            int myt = PagesList.Items.IndexOf(t1);
            if (myt == notePages.IndexOf(currentPage))
            {
                clearScreenOfPage();
            }
            notePages.Remove(notePages[myt]);
            PagesList.Items.Remove(t1);

            if (PagesList.Items.IsEmpty)
            {

            }
            else if (myt == PagesList.Items.Count)
            {
                PagesList.SelectedItem = PagesList.Items[myt - 1];
            }
            else
            {
                PagesList.SelectedItem = PagesList.Items[myt];
            }
        }
        #endregion

        #region 비트맵 캡처 관련 함수
        private async Task sccap(Rectangle captureRect)
        {
            BitmapSource bmpsource = null;
            //this.Hide();
            //this.Dispatcher.Invoke((ThreadStart)(() => { }), System.Windows.Threading.DispatcherPriority.ApplicationIdle);
            double x = captureRect.PointFromScreen(new System.Windows.Point(0d, 0d)).X;
            double y = captureRect.PointFromScreen(new System.Windows.Point(0d, 0d)).Y;

            //PresentationSource source = PresentationSource.FromVisual(this);
            //Dispatcher.Invoke(new Action(() => { }), DispatcherPriority.ContextIdle, null);
            var wpfActiveScreen = System.Windows.Forms.Screen.FromHandle(new System.Windows.Interop.WindowInteropHelper(this).Handle);
            //var t = PresentationSource.FromVisual(source).CompositionTarget.TransformToDevice;

            //Point p1 = t.Transform(new Point(captureRect.Margin.Left, captureRect.Margin.Top));
            //Point p2 = t.Transform(new Point(captureRect.Margin.Left + captureRect.Width, captureRect.Margin.Top + captureRect.Height));
            System.Drawing.Bitmap localBmp = new System.Drawing.Bitmap((int)(captureRect.Width * DpiScaleX), (int)(captureRect.Height * DpiScaleY), System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            IntPtr bmptr;
            using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(localBmp))
            {


                //Dispatcher.Invoke(new Action(() => { HideAll(); }), System.Windows.Threading.DispatcherPriority.Send, null);
                //Application.Current.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle, new Action(() => { g.CopyFromScreen((int)((wpfActiveScreen.Bounds.X - x) * DpiScaleX), (int)((wpfActiveScreen.Bounds.Y - y) * DpiScaleY), 0, 0, localBmp.Size, System.Drawing.CopyPixelOperation.SourceCopy); })).Wait();
                //Application.Current.Dispatcher.Invoke(new Action(() => { this.Opacity = 0.01; g.CopyFromScreen((int)((wpfActiveScreen.Bounds.X - x) * DpiScaleX), (int)((wpfActiveScreen.Bounds.Y - y) * DpiScaleY), 0, 0, localBmp.Size, System.Drawing.CopyPixelOperation.SourceCopy); }));
                //g.CopyFromScreen((int)((wpfActiveScreen.Bounds.X - x) * DpiScaleX), (int)((wpfActiveScreen.Bounds.Y - y) * DpiScaleY), 0, 0, localBmp.Size, System.Drawing.CopyPixelOperation.SourceCopy);
                Opacity = 0.001;
                await Task.Run(async () => await Task.Delay(50));
                g.CopyFromScreen((int)((wpfActiveScreen.Bounds.X - x) * DpiScaleX), (int)((wpfActiveScreen.Bounds.Y - y) * DpiScaleY), 0, 0, localBmp.Size, System.Drawing.CopyPixelOperation.SourceCopy);
                Opacity = 1;
                //CaptureRect.StrokeThickness = 3;
                if (localBmp != null)
                {
                    bmptr = localBmp.GetHbitmap();
                    bmpsource = Imaging.CreateBitmapSourceFromHBitmap(bmptr, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
                    //DisplayRect.Fill = new ImageBrush(bmpsource);

                    /*SaveFileDialog sfd = new SaveFileDialog();
                    sfd.Filter = "JPG File(*.jpg) | *.jpg";
                    if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        localBmp.Save(sfd.FileName);
                    }*/

                }
                else { bmpsource = null; }
                tempImg = bmpsource;
            }
        }

        private async Task exportCap(Rectangle captureRect)
        {
            double x = captureRect.PointFromScreen(new System.Windows.Point(0d, 0d)).X;
            double y = captureRect.PointFromScreen(new System.Windows.Point(0d, 0d)).Y;
            var wpfActiveScreen = System.Windows.Forms.Screen.FromHandle(new System.Windows.Interop.WindowInteropHelper(this).Handle);
            System.Drawing.Bitmap localBmp = new System.Drawing.Bitmap((int)(captureRect.Width * DpiScaleX), (int)(captureRect.Height * DpiScaleY), System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            IntPtr bmptr;
            using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(localBmp))
            {
                await Task.Run(async () => await Task.Delay(200));
                g.CopyFromScreen((int)((wpfActiveScreen.Bounds.X - x) * DpiScaleX), (int)((wpfActiveScreen.Bounds.Y - y) * DpiScaleY), 0, 0, localBmp.Size, System.Drawing.CopyPixelOperation.SourceCopy);
                //CaptureRect.StrokeThickness = 3;
                if (localBmp != null)
                {
                    bmptr = localBmp.GetHbitmap();
                    tempbmp = System.Drawing.Bitmap.FromHbitmap(bmptr);
                    //bmpsource = Imaging.CreateBitmapSourceFromHBitmap(bmptr, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
                }
                else { //bmpsource = null; }
                       }
            }
        }

        private BitmapImage BtoB(System.Drawing.Bitmap e)
        {

            return new BitmapImage();
        }

        private void clearScreenOfPage()
        {
            if (currentPage != null)
            {
                for (int i = 0; i < currentPage.Notations.Count; i++)
                {
                    MainGrid.Children.Remove(currentPage.Notations[i]);
                }
            }
            if (backGroundImgShown)
            {
                CaptureArea.currentRect.Fill = Brushes.Transparent;
            }
        }

        private void loadScreenFromPage(NotePage e)
        {
            if (currentPage == e) { return; }
            currentPage = e;
            MainGrid.Children.Remove(RecordArea);
            RecordArea = e.PageArea;
            MainGrid.Children.Add(RecordArea);
            for (int i = 0; i < e.Notations.Count; i++)
            {
                MainGrid.Children.Add(e.Notations[i]);
            }
            if (backGroundImgShown)
            {
                if (e.candidateImages.Count == 0)
                {
                    
                    return;
                }
                RecordArea.innerRect.Fill = new ImageBrush(e.candidateImages[e.MainCandidateImageIndex]);
            }
            killFocus(null);
        }

        private int comparebitmaps(BitmapSource a, BitmapSource b, int divisions)
        {
            if (a.Width != b.Width || a.Height != b.Height) { return 65535; }

            int Difference = 0;
            System.Drawing.Bitmap bitA = GetBitmapFromBitmapSource(a);
            System.Drawing.Bitmap bitB = GetBitmapFromBitmapSource(b);
            System.Drawing.Bitmap transA = ApplyNormalPixelate(ref bitA, divisions);
            System.Drawing.Bitmap transB = ApplyNormalPixelate(ref bitB, divisions);
            for (int i = 0; i < transA.Width; i++)
            {
                for (int f = 0; f < transA.Height; f++)
                {
                    if (transA.GetPixel(i, f).GetBrightness() != transB.GetPixel(i, f).GetBrightness())
                    {
                        Difference++;
                    }
                }
            }
            return Difference;
        }
        private System.Drawing.Bitmap ApplyNormalPixelate(ref System.Drawing.Bitmap originalBmp, int divisions)
        {
            int t = originalBmp.Height / (originalBmp.Width / divisions);
            System.Drawing.Size newsize = new System.Drawing.Size(divisions, t);
            return new System.Drawing.Bitmap(originalBmp, newsize);
        }
        

        private System.Drawing.Bitmap GetBitmapFromBitmapSource(BitmapSource bitmapSource)
        {
            System.Drawing.Bitmap bitmap;


            using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream())
            {
                BitmapEncoder bitmapEncoder = new BmpBitmapEncoder();
                bitmapEncoder.Frames.Add(BitmapFrame.Create(bitmapSource));
                bitmapEncoder.Save(memoryStream);


                bitmap = new System.Drawing.Bitmap(memoryStream);
            }


            return bitmap;
        }
        #endregion

        private void killFocus(object Source)
        {
            if (Source == TextOptions) { 
                return; }
            if (currentPage == null) { return; }
            bool istxt = false;
            Resizables.SelectMode txtmode = Resizables.SelectMode.NON;
            if (Source is NTextBox)
            {
                istxt = true;
                txtmode = (Source as NTextBox).SelVarChange;
            }
            //control 0 thru 1
            int tmpType = -1;

            int temp = -1;
            for (int i = 0; i < currentPage.Notations.Count; i++)
            {
                if (Source != currentPage.Notations[i])
                {
                    currentPage.Notations[i].SelVarChange = Resizables.SelectMode.NON;

                }
                else
                {
                    temp = i; tmpType = 0;
                    selection = currentPage.Notations[i]; selectionType = 0;
                }
            }
            for (int t = 0; t < currentSettings.Punches.Count; t++)
            {
                if (Source != currentSettings.Punches[t])
                {
                    currentSettings.Punches[t].SelVarChange = Resizables.SelectMode.NON;

                }
                else
                {
                    temp = t; tmpType = 1;
                    selection = currentSettings.Punches[t]; selectionType = 1;
                }
            }
            if (temp != -1)
            {
                if (tmpType == 0)
                {
                    selection = currentPage.Notations[temp];
                    for (int f = 0; f < currentPage.Notations.Count; f++)
                    {
                        if (f != temp)
                        {
                            currentPage.Notations[f].SelVarChange = Resizables.SelectMode.NON;
                        }
                    }
                    if (currentPage.Notations[temp].SelVarChange == Resizables.SelectMode.MOV)
                    {
                        
                        TBin.Focus();
                        Keyboard.Focus(TBin);
                    }
                }
                else if (tmpType == 1)
                {
                    selection = currentSettings.Punches[temp];
                    for (int f = 0; f < currentSettings.Punches.Count; f++)
                    {
                        if (f != temp)
                        {
                            currentSettings.Punches[f].SelVarChange = Resizables.SelectMode.NON;
                        }
                    }
                    if (currentSettings.Punches[temp].SelVarChange == Resizables.SelectMode.MOV)
                    {
                        TBin.Focus();
                        Keyboard.Focus(TBin);
                    }
                }
            }
            else
            {
                selection = null;
                TBin.Focus();
                Keyboard.Focus(TBin);
            }

            if (istxt)
            {
                switch (txtmode)
                {
                    case Resizables.SelectMode.MOV:
                        //killFocus(null);
                        (Source as NTextBox).SelVarChange = Resizables.SelectMode.MOV;
                        TBin.Focus();
                        Keyboard.Focus(TBin);
                        break;
                    case Resizables.SelectMode.NON:

                        break;
                    case Resizables.SelectMode.TXT:
                        for (int f = 0; f < currentPage.Notations.Count; f++)
                        {
                            currentPage.Notations[f].SelVarChange = Resizables.SelectMode.NON;
                        }
                        (Source as NTextBox).SelVarChange = Resizables.SelectMode.TXT;
                        //(Source as NTextBox).MainContent.Focus();
                        //Keyboard.Focus((Source as NTextBox).MainContent);
                        break;
                }
            }
        }

        private void prevKeyDown(object sender, KeyEventArgs e)
        {
            #region 원판 소환
            if (e.Key == Key.LeftCtrl)
            {
                if (currentPage == null) { return; }
                if (CircularMenu || CreatingCtrl != SubjectSettings.TypesOfCtrls.NONE) 
                {
                    //CreatingCtrl = SubjectSettings.TypesOfCtrls.NONE;
                    //CDirection = circularSelect.Center;
                    return;
                }
                Circularpos = Mouse.GetPosition(this);
                if (Circularpos.X < 60 || Circularpos.Y < 60) { return; }
                CircularMenu = true;
                ForceCursor = true;
                Cursor = Cursors.Arrow;


                PingGrid.Margin = new Thickness(Circularpos.X - 60, Circularpos.Y - 60, 0, 0);

                MainGrid.Children.Add(PingGrid);


            }
            #endregion

            #region 방향키로 원소 이동
            if (selection != null && selection.SelVarChange == Resizables.SelectMode.MOV)
            {
                selection.moveByKey(e);
            }
            #endregion

            if (e.Key == Key.Escape&& CreatingCtrl != SubjectSettings.TypesOfCtrls.NONE)
            {
                CreatingCtrl = SubjectSettings.TypesOfCtrls.NONE;
                Cursor = Cursors.Arrow;
                CDirection = circularSelect.Center;
                ForceCursor = false;
            }

            #region Del키로 원소 삭제
            if (e.Key == Key.Delete && selection != null && selection.SelVarChange == Resizables.SelectMode.MOV)
            {
                if (selectionType == 0)
                {
                    currentPage.Notations.Remove(selection);
                    MainGrid.Children.Remove(selection);
                    if (currentPage.Notations.Count == 0)
                    {
                        RecordArea.UNLOCK();
                    }
                }
                else if (selectionType == 1)
                {
                    currentSettings.Punches.Remove((clickThru)selection);

                    MainGrid.Children.Remove(selection);

                }
                TBin.Focus();
                Keyboard.Focus(TBin);
            }
            #endregion

            #region 생성시 outfocus참고코드
            /*
                        if (e.Key == Key.D3 && Keyboard.IsKeyDown(Key.LeftCtrl))
                        {
                            CreatingCtrl = true;
                            ForceCursor = true;
                            Cursor = Cursors.Cross;
                            //control 0 thru 1
                            int tmpType = -1;

                            int temp = -1;
                            for (int i = 0; i < PageComponents.Count; i++)
                            {
                                if (e.Source != PageComponents[i])
                                {
                                    PageComponents[i].SelVarChange = Resizables.SelectMode.NON;

                                }
                                else
                                {
                                    temp = i; tmpType = 0;
                                    selection = PageComponents[i]; selectionType = 0;
                                }
                            }
                            for (int t = 0; t < ThruBoxes.Count; t++)
                            {
                                if (e.Source != ThruBoxes[t])
                                {
                                    ThruBoxes[t].SelVarChange = Resizables.SelectMode.NON;

                                }
                                else
                                {
                                    temp = t; tmpType = 1;
                                    selection = ThruBoxes[t]; selectionType = 1;
                                }
                            }
                            if (temp != -1)
                            {
                                if (tmpType == 0)
                                {
                                    for (int f = 0; f < PageComponents.Count; f++)
                                    {
                                        if (f != temp)
                                        {
                                            PageComponents[f].SelVarChange = Resizables.SelectMode.NON;
                                        }
                                    }
                                    if (PageComponents[temp].SelVarChange == Resizables.SelectMode.MOV)
                                    {
                                        TBin.Focus();
                                        Keyboard.Focus(TBin);
                                    }
                                }
                                else if (tmpType == 1)
                                {
                                    for (int f = 0; f < ThruBoxes.Count; f++)
                                    {
                                        if (f != temp)
                                        {
                                            ThruBoxes[f].SelVarChange = Resizables.SelectMode.NON;
                                        }
                                    }
                                    if (ThruBoxes[temp].SelVarChange == Resizables.SelectMode.MOV)
                                    {
                                        TBin.Focus();
                                        Keyboard.Focus(TBin);
                                    }
                                }
                            }
                            else
                            {
                                TBin.Focus();
                                Keyboard.Focus(TBin);
                            }
                        }*/
            #endregion
        }
        private void prevKeyUp(object sender, KeyEventArgs e)
        {
            #region 원판지시로 컨트롤생성
            if (CircularMenu && e.Key == Key.LeftCtrl)
            {
                switch (CDirection)
                {
                    case circularSelect.Center:
                        ForceCursor = false;
                        break;
                    case circularSelect.N:
                        if (currentSettings.North.CtrlType == SubjectSettings.TypesOfCtrls.NONE)
                        {
                            ForceCursor = false;
                            CircularMenu = false;
                            MainGrid.Children.Remove(PingGrid);
                            return;
                        }
                        mouseListenerPause = true;
                        CreatingCtrl = currentSettings.North.CtrlType;
                        ForceCursor = true;
                        Cursor = Cursors.Cross;
                        killFocus(null);
                        break;
                    case circularSelect.W:
                        if (currentSettings.West.CtrlType == SubjectSettings.TypesOfCtrls.NONE)
                        {
                            ForceCursor = false;
                            CircularMenu = false;
                            MainGrid.Children.Remove(PingGrid);
                            return;
                        }
                        mouseListenerPause = true;
                        CreatingCtrl = currentSettings.West.CtrlType;
                        ForceCursor = true;
                        Cursor = Cursors.Cross;
                        killFocus(null);
                        break;
                    case circularSelect.S:
                        if (currentSettings.South.CtrlType == SubjectSettings.TypesOfCtrls.NONE)
                        {
                            ForceCursor = false;
                            CircularMenu = false;
                            MainGrid.Children.Remove(PingGrid);
                            return;
                        }
                        mouseListenerPause = true;
                        CreatingCtrl = currentSettings.South.CtrlType;
                        ForceCursor = true;
                        Cursor = Cursors.Cross;
                        killFocus(null);
                        break;
                    case circularSelect.E:
                        if (currentSettings.East.CtrlType == SubjectSettings.TypesOfCtrls.NONE)
                        {
                            ForceCursor = false;
                            CircularMenu = false;
                            MainGrid.Children.Remove(PingGrid);
                            return;
                        }
                        mouseListenerPause = true;
                        CreatingCtrl = currentSettings.East.CtrlType;
                        ForceCursor = true;
                        Cursor = Cursors.Cross;
                        killFocus(null);
                        break;
                }
                CircularMenu = false;
                MainGrid.Children.Remove(PingGrid);
            }
            #endregion
        }

        private void outer_mouse_up(object sender, MouseButtonEventArgs e)
        {
            #region 사각형 드래그로 원소 생성
            if (CreatingCtrl != SubjectSettings.TypesOfCtrls.NONE && isTempRect)
            {
                if (temprect == null)
                {
                    CreatingCtrl = SubjectSettings.TypesOfCtrls.NONE; ForceCursor = false; Cursor = Cursors.Arrow; return;
                }
                Resizables newbox;
                MainGrid.Children.Remove(temprect);
                mouseListenerPause = false;
                
                switch (CreatingCtrl)
                {

                    case SubjectSettings.TypesOfCtrls.Highlighter:
                        RecordArea.LOCK();
                        newbox = new Highlighter();
                        break;
                    case SubjectSettings.TypesOfCtrls.NTextBox:
                        RecordArea.LOCK();
                        newbox = new NTextBox();
                        break;
                    case SubjectSettings.TypesOfCtrls.Underline:
                        RecordArea.LOCK();
                        newbox = new ScreenControls.Underline();
                        break;
                    case SubjectSettings.TypesOfCtrls.clickThru:
                        Rect t1 = new Rect(Math.Min(tempx1, tempx2), Math.Min(tempy1, tempy2), Math.Abs(tempx2 - tempx1), Math.Abs(tempy2 - tempy1));
                        newbox = new clickThru();
                        newbox.init(t1.X, t1.Y, t1.X + t1.Width, t1.Y + t1.Height);
                        currentSettings.Punches.Add(newbox as clickThru);
                        MainGrid.Children.Add(newbox);
                        killFocus(newbox);
                        selection = newbox;
                        newbox.SelVarChange = Resizables.SelectMode.MOV;
                        ForceCursor = false;
                        Cursor = Cursors.Arrow;
                        CreatingCtrl = SubjectSettings.TypesOfCtrls.NONE;
                        return;
                    default:
                        newbox = new NTextBox();
                        break;
                }


                Rect t = new Rect(Math.Min(tempx1, tempx2), Math.Min(tempy1, tempy2), Math.Abs(tempx2 - tempx1), Math.Abs(tempy2 - tempy1));
                Rect newt = Resizables.CutRect(Resizables.RectToRect(CaptureArea.currentRect), t, true);
                ControlProperties prop = currentSettings.getPreset(CDirection);
                newbox.InitiateFromPreset(newt.X, newt.Y, newt.X + newt.Width, newt.Y + newt.Height, prop);
                MainGrid.Children.Add(newbox);
                currentPage.Notations.Add(newbox);
                killFocus(newbox);
                if (CreatingCtrl != SubjectSettings.TypesOfCtrls.NTextBox)
                {
                    selection = newbox;
                    newbox.SelVarChange = Resizables.SelectMode.MOV;
                }
                ForceCursor = false;
                Cursor = Cursors.Arrow;
                CreatingCtrl = SubjectSettings.TypesOfCtrls.NONE;
            }
            #endregion
            /*
            for (int i = 0; i < currentPage.Notations.Count; i++)
            {
                currentPage.Notations[i].TxtMouseUp(sender, e);
            }
            for (int i = 0; i < currentSettings.Punches.Count; i++)
            {
                currentSettings.Punches[i].TxtMouseUp(sender, e);
            }
            */
        }

        #region DPI 검색함수
        private void CurrentWindowFindDpi()
        {
            PresentationSource source = PresentationSource.FromVisual(this);
            dpiX = 1; dpiY = 1;
            if (source != null)
            {
                dpiX = 96.0 * source.CompositionTarget.TransformToDevice.M11;
                dpiY = 96.0 * source.CompositionTarget.TransformToDevice.M22;
            }
            DpiScaleX = Math.Round(dpiX / (double)96, 2);
            DpiScaleY = Math.Round(dpiY / (double)96, 2);
        }

        public static Grid PingImgFromSettings(SubjectSettings e)
        {
            Grid tgrid = new Grid();
            tgrid.HorizontalAlignment = HorizontalAlignment.Left;
            tgrid.VerticalAlignment = VerticalAlignment.Top;
            tgrid.Visibility = Visibility.Visible;
            tgrid.IsEnabled = true;
            tgrid.Width = 120;
            tgrid.Height = 120;
            Image CenterImage = new Image();
            Image WestImage = new Image();
            Image EastImage = new Image();
            Image SouthImage = new Image();
            Image NorthImage = new Image();
            CenterImage.Width = CenterImage.Height = 120;
            CenterImage.Source = new BitmapImage(new Uri(@"/icos/main_72DPI.png", UriKind.Relative));
            CenterImage.Margin = new Thickness(0, 0, 0, 0);
            CenterImage.IsEnabled = true;
            CenterImage.Name = "centerimg";
            tgrid.Children.Add(CenterImage);
            NorthImage.HorizontalAlignment = WestImage.HorizontalAlignment = EastImage.HorizontalAlignment = SouthImage.HorizontalAlignment = HorizontalAlignment.Left;
            NorthImage.VerticalAlignment = WestImage.VerticalAlignment = EastImage.VerticalAlignment = SouthImage.VerticalAlignment = VerticalAlignment.Top;
            WestImage.IsEnabled = true;
            EastImage.IsEnabled = true;
            SouthImage.IsEnabled = true;
            NorthImage.IsEnabled = true;
            if(e.North == null)
            {

            }
            else if (e.North.CtrlType == SubjectSettings.TypesOfCtrls.NTextBox)
            {
                NorthImage.Width = NorthImage.Height = 30;
                NorthImage.Source = new BitmapImage(new Uri(@"/icos/icon_Text_Box.png", UriKind.Relative));
                NorthImage.Margin = new Thickness(45, 9, 0, 0);
                tgrid.Children.Add(NorthImage);
            }
            else if (e.North.CtrlType == SubjectSettings.TypesOfCtrls.Highlighter)
            {
                NorthImage.Width = 38; NorthImage.Height = 12;
                NorthImage.Source = new BitmapImage(new Uri(@"/icos/yellowPenDown.png", UriKind.Relative));
                NorthImage.Margin = new Thickness(41, 18, 0, 0);
                tgrid.Children.Add(NorthImage);
            }
            else if (e.North.CtrlType == SubjectSettings.TypesOfCtrls.Underline)
            {
                NorthImage.Width = 38; NorthImage.Height = 12;
                NorthImage.Source = new BitmapImage(new Uri(@"/icos/redPenDown.png", UriKind.Relative));
                NorthImage.Margin = new Thickness(41, 18, 0, 0);
                tgrid.Children.Add(NorthImage);
            }

            if (e.South == null)
            {

            }
            else if (e.South.CtrlType == SubjectSettings.TypesOfCtrls.NTextBox)
            {
                SouthImage.Width = SouthImage.Height = 30;
                SouthImage.Source = new BitmapImage(new Uri(@"/icos/icon_Text_Box.png", UriKind.Relative));
                SouthImage.Margin = new Thickness(45, 81, 0, 0);
                tgrid.Children.Add(SouthImage);
            }
            else if (e.South.CtrlType == SubjectSettings.TypesOfCtrls.Highlighter)
            {
                SouthImage.Width = 38; SouthImage.Height = 12;
                SouthImage.Source = new BitmapImage(new Uri(@"/icos/yellowPenDown.png", UriKind.Relative));
                SouthImage.Margin = new Thickness(41, 90, 0, 0);
                tgrid.Children.Add(SouthImage);
            }
            else if (e.South.CtrlType == SubjectSettings.TypesOfCtrls.Underline)
            {
                SouthImage.Width = 38; SouthImage.Height = 12;
                SouthImage.Source = new BitmapImage(new Uri(@"/icos/redPenDown.png", UriKind.Relative));
                SouthImage.Margin = new Thickness(41, 90, 0, 0);
                tgrid.Children.Add(SouthImage);
            }

            if (e.West == null)
            {

            }
            else if (e.West.CtrlType == SubjectSettings.TypesOfCtrls.NTextBox)
            {
                WestImage.Width = WestImage.Height = 30;
                WestImage.Source = new BitmapImage(new Uri(@"/icos/icon_Text_Box.png", UriKind.Relative));
                WestImage.Margin = new Thickness(9, 45, 0, 0);
                tgrid.Children.Add(WestImage);
            }
            else if (e.West.CtrlType == SubjectSettings.TypesOfCtrls.Highlighter)
            {
                WestImage.Width = 12; WestImage.Height = 38;
                WestImage.Source = new BitmapImage(new Uri(@"/icos/Pen_Yello_72ppi.png", UriKind.Relative));
                WestImage.Margin = new Thickness(18, 41, 0, 0);
                tgrid.Children.Add(WestImage);
            }
            else if (e.West.CtrlType == SubjectSettings.TypesOfCtrls.Underline)
            {
                WestImage.Width = 12; WestImage.Height = 38;
                WestImage.Source = new BitmapImage(new Uri(@"/icos/Pen_Red_72ppi.png", UriKind.Relative));
                WestImage.Margin = new Thickness(18, 41, 0, 0);
                tgrid.Children.Add(WestImage);
            }

            if (e.East == null)
            {

            }
            else if (e.East.CtrlType == SubjectSettings.TypesOfCtrls.NTextBox)
            {
                EastImage.Width = EastImage.Height = 30;
                EastImage.Source = new BitmapImage(new Uri(@"/icos/icon_Text_Box.png", UriKind.Relative));
                EastImage.Margin = new Thickness(81, 45, 0, 0);
                tgrid.Children.Add(EastImage);
            }
            else if (e.East.CtrlType == SubjectSettings.TypesOfCtrls.Highlighter)
            {
                EastImage.Width = 12; EastImage.Height = 38;
                EastImage.Source = new BitmapImage(new Uri(@"/icos/Pen_Yello_72ppi.png", UriKind.Relative));
                EastImage.Margin = new Thickness(90, 41, 0, 0);
                tgrid.Children.Add(EastImage);
            }
            else if (e.East.CtrlType == SubjectSettings.TypesOfCtrls.Underline)
            {
                EastImage.Width = 12; EastImage.Height = 38;
                EastImage.Source = new BitmapImage(new Uri(@"/icos/Pen_Red_72ppi.png", UriKind.Relative));
                EastImage.Margin = new Thickness(90, 41, 0, 0);
                tgrid.Children.Add(EastImage);
            }

            return tgrid;
        }
        #endregion

        private void outer_mouse_move(object sender, MouseEventArgs e)
        {
            #region 원판 계산 및 처리
            if (CircularMenu)
            {
                Image centerImg = System.Windows.LogicalTreeHelper.FindLogicalNode(PingGrid, "centerimg") as Image;
                Point CurrentPos = e.GetPosition(this);
                Point Relative = new Point(CurrentPos.X - Circularpos.X, Circularpos.Y - CurrentPos.Y);
                double distance = Math.Sqrt(Relative.X * Relative.X + Relative.Y * Relative.Y);
                double angle = ((Math.Atan2(Relative.Y, Relative.X) * 180 / Math.PI) + 360) % 360;
                if (distance < 15)
                {
                    CDirection = circularSelect.Center;
                    centerImg.Source = cM;
                }
                else if (angle >= 45 && angle < 135)
                {
                    CDirection = circularSelect.N;
                    centerImg.Source = cN;
                }
                else if (angle >= 135 && angle < 225)
                {
                    CDirection = circularSelect.W;
                    centerImg.Source = cW;
                }
                else if (angle >= 225 && angle < 315)
                {
                    CDirection = circularSelect.S;
                    centerImg.Source = cS;
                }
                else if (angle >= 315 || angle < 45)
                {
                    CDirection = circularSelect.E;
                    centerImg.Source = cE;
                }

            }
            #endregion
            #region 십자드래그
            if (CreatingCtrl != SubjectSettings.TypesOfCtrls.NONE && temprect != null)
            {
                Point p2 = Mouse.GetPosition(this);
                tempx2 = p2.X; tempy2 = p2.Y;
                
                
                temprect.Width = Math.Abs(tempx2 - tempx1);
                if (CreatingCtrl == SubjectSettings.TypesOfCtrls.Underline)
                {
                    double thickt = (currentSettings.getPreset(CDirection) as UnderlineProperty).Thick;


                    temprect.Height = thickt;
                    temprect.Margin = new Thickness(Math.Min(tempx1, tempx2), tempy1, 0, 0);
                }
                else
                {
                    temprect.Height = Math.Abs(tempy2 - tempy1);
                    temprect.Margin = new Thickness(Math.Min(tempx1, tempx2), Math.Min(tempy1, tempy2), 0, 0);
                }
                return;
            }
            #endregion
            #region 마우스 MOV드래그 이탈시 처리
            if (currentPage != null)
            {
                for (int i = 0; i < currentPage.Notations.Count; i++)
                {
                    currentPage.Notations[i].Movement_Regulator(sender, e);
                }
                for (int i = 0; i < currentSettings.Punches.Count; i++)
                {
                    currentSettings.Punches[i].Movement_Regulator(sender, e);
                }
            }

            #endregion
        }

        private void outerprevMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Source is NTextBox && e.LeftButton == MouseButtonState.Pressed)
            {
                killFocus(e.Source);
            }
        }
        private void outer_mouse_down(object sender, MouseEventArgs e)
        {
            killFocus(e.Source);
            #region 십자드래그 임시사각형 생성
            if (CreatingCtrl != SubjectSettings.TypesOfCtrls.NONE)
            {
                Point p1 = e.GetPosition(this);
                if (CreatingCtrl != SubjectSettings.TypesOfCtrls.clickThru && !Resizables.RectToRect(RecordArea.innerRect).Contains(p1)) { CreatingCtrl = SubjectSettings.TypesOfCtrls.NONE; ForceCursor = false; Cursor = Cursors.Arrow; return; }
                tempx1 = p1.X; tempy1 = p1.Y; tempx2 = tempx1 + 20; tempy2 = tempy1 + 20;
                temprect = new Rectangle();
                temprect.Margin = new Thickness(p1.X, p1.Y, 0, 0);
                temprect.Width = 0; temprect.Height = 0;
                temprect.Fill = Brushes.Orange;
                temprect.HorizontalAlignment = HorizontalAlignment.Left;
                temprect.VerticalAlignment = VerticalAlignment.Top;

                temprect.Opacity = 0.4;
                MainGrid.Children.Add(temprect);
                isTempRect = true;
                return;
            }
            #endregion

            killFocus(e.Source);
            #region killFocus참고코드
            //control 0 thru 1
            /*
            int tmpType = -1;
            int temp = -1;
            for (int i = 0; i < PageComponents.Count; i++)
            {
                if (e.Source != PageComponents[i])
                {
                    PageComponents[i].SelVarChange = Resizables.SelectMode.NON;

                }
                else
                {
                    temp = i; tmpType = 0;
                    selection = PageComponents[i]; selectionType = 0;
                }
            }
            for (int t = 0; t < ThruBoxes.Count; t++)
            {
                if (e.Source != ThruBoxes[t])
                {
                    ThruBoxes[t].SelVarChange = Resizables.SelectMode.NON;

                }
                else
                {
                    temp = t; tmpType = 1;
                    selection = ThruBoxes[t]; selectionType = 1;
                }
            }
            if (temp != -1)
            {
                if (tmpType == 0)
                {
                    for (int f = 0; f < PageComponents.Count; f++)
                    {
                        if (f != temp)
                        {
                            PageComponents[f].SelVarChange = Resizables.SelectMode.NON;
                        }
                    }
                    if (PageComponents[temp].SelVarChange == Resizables.SelectMode.MOV)
                    {
                        TBin.Focus();
                        Keyboard.Focus(TBin);
                    }
                }
                else if (tmpType == 1)
                {
                    for (int f = 0; f < ThruBoxes.Count; f++)
                    {
                        if (f != temp)
                        {
                            ThruBoxes[f].SelVarChange = Resizables.SelectMode.NON;
                        }
                    }
                    if (ThruBoxes[temp].SelVarChange == Resizables.SelectMode.MOV)
                    {
                        TBin.Focus();
                        Keyboard.Focus(TBin);
                    }
                }
            }
            else
            {
                TBin.Focus();
                Keyboard.Focus(TBin);
            }
            */
            #endregion
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            var hwnd = new WindowInteropHelper(this).Handle;
            int extendedStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
            SetWindowLong(hwnd, GWL_EXSTYLE, extendedStyle & ~WS_EX_TRANSPARENT);
            CurrentWindowFindDpi();

            if (!PagesList.Items.IsEmpty)
            {
                PagesList.SelectedItem = PagesList.Items[0];
            }
        }

        #region 최우측 버튼 클릭처리기
        private void CloseWindow_Click(object sender, RoutedEventArgs e)
        {
            globalMouseListener.Abort();
            captureThread.Abort();
            Close();
        }
        private void MinimizeWindow_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }
        #endregion

        private void HideorShow_Click(object sender, RoutedEventArgs e)
        {
            if (!backGroundImgShown)
            {
                if (isRecording)
                {
                    isRecording = false;
                    RecordImg.Source = new BitmapImage(new Uri(@"/icos/icon_Rec.png", UriKind.Relative));
                }
                backGroundImgShown = true;
                if (currentPage.candidateImages.Count == 0)
                {
                    RecordArea.innerRect.Fill = Brushes.Transparent;
                    return;
                }
                RecordArea.innerRect.Fill = new ImageBrush(currentPage.candidateImages[currentPage.MainCandidateImageIndex]);
            }
            else
            {
                backGroundImgShown = false;
                RecordArea.innerRect.Fill = Brushes.Transparent;
            }
        }


        private async void AddCapture_Click(object sender, RoutedEventArgs e)
        {
            if (PagesList.Items.Count == 0) { return; }
            tempImg = null;
            await sccap(RecordArea.innerRect);

            StackPanel np = ((ListBoxItem)(PagesList.SelectedItem)).Content as StackPanel;
            if (np == null) { return; }
            Image ni = null;
            for (int i = 0; i < np.Children.Count; i++)
            {
                if(np.Children[i] is Image)
                {
                    ni = np.Children[i] as Image;
                }
            }
            if (ni == null) { return; }

            currentPage.candidateImages.Add(tempImg);
            currentPage.MainCandidateImageIndex = currentPage.candidateImages.IndexOf(tempImg);

            ni.Source = tempImg;

        }

        private void Record_Click(object sender, RoutedEventArgs e)
        {
            if (!isRecording)
            {
                if (backGroundImgShown)
                {
                    backGroundImgShown = false;
                    RecordArea.innerRect.Fill = Brushes.Transparent;
                }
                isRecording = true;
            }
            else
            {
                isRecording = false;
            }
        }

        private void NewPage_Click(object sender, RoutedEventArgs e)
        {
            BrandNewPage();
        }

        private async void newPagebyCapture_Click(object sender, RoutedEventArgs e)
        {
            backGroundImgShown = false;
            tempImg = null;
            if (notePages.Count == 0) { await Task.Run(async () => await Task.Delay(150)); }
            await sccap(RecordArea.innerRect);

            NotePage nNotePage = new NotePage();
            nNotePage.PageArea = new CaptureArea();
            nNotePage.PageArea.init(RecordArea.innerRect.Margin.Left - 5, RecordArea.innerRect.Margin.Top - 5, RecordArea.innerRect.Margin.Left + RecordArea.innerRect.Width + 5, RecordArea.innerRect.Margin.Top + RecordArea.innerRect.Height + 5);
            if (tempImg != null)
            {
                nNotePage.candidateImages.Add(tempImg);
            }
            notePages.Add(nNotePage);

            ListBoxItem tempt = BoxItemFromPage(nNotePage);
            PagesList.Items.Add(tempt);
            PagesList.SelectedItem = tempt;

        }

        private void ListSelChanged(object sender, RoutedEventArgs e)
        {
            int PageNo = PagesList.Items.IndexOf(PagesList.SelectedItem);
            if (PageNo == -1) { return; }
            clearScreenOfPage();
            //RecordArea = notePages[PageNo].PageArea;
            loadScreenFromPage(notePages[PageNo]);
            if (currentPage.Notations.Count == 0)
            {
                RecordArea.UNLOCK();
            }
            else
            {
                RecordArea.LOCK();
            }
        }

        private void titleRect_MouseLeave(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && isToolMoving)
            {
                titleRect_MouseMove(sender, e);
            }
            else { Cursor = Cursors.Arrow; }
        }

        private void titleRect_MouseEnter(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.SizeAll;

        }

        private void titleRect_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ToolOriginalPoint = e.GetPosition(this);
            isToolMoving = true;
            ToolOriginalVector = new Point(innerGrid.Margin.Left - ToolOriginalPoint.X, innerGrid.Margin.Top - ToolOriginalPoint.Y);
        }

        private void titleRect_MouseMove(object sender, MouseEventArgs e)
        {
            if (isToolMoving)
            {
                Point pa = e.GetPosition(this);
                innerGrid.Margin = new Thickness(pa.X + ToolOriginalVector.X, pa.Y + ToolOriginalVector.Y, 0, 0);
            }
        }

        private void titleRect_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isToolMoving = false;
        }

        private void PunchHole_Click(object sender, RoutedEventArgs e)
        {
            CreatingCtrl = SubjectSettings.TypesOfCtrls.clickThru;
            ForceCursor = true;
            Cursor = Cursors.Cross;
            killFocus(null);
        }

        private void FontColorBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void cbxFont_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (selection is NTextBox)
            {
                if ((selection as NTextBox).MainContent != null)
                {
                    (selection as NTextBox).MainContent.FontFamily = new FontFamily(listFont[cbxFont.Items.IndexOf(cbxFont.SelectedItem)]);
                }
            }
        }
        private static bool IsTextNumeric(string str)
        {
            System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex("[^0-9]");
            return reg.IsMatch(str);

        }
        private void FontSizeBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = IsTextNumeric(e.Text);

        }
        private void FontSizeBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            Int32 selectionStart = textBox.SelectionStart;
            Int32 selectionLength = textBox.SelectionLength;
            String newText = String.Empty;
            int count = 0;
            foreach (Char c in textBox.Text.ToCharArray())
            {
                if (Char.IsDigit(c) || Char.IsControl(c) || (c == '.' && count == 0))
                {
                    newText += c;
                    if (c == '.')
                        count += 1;
                }
            }
            textBox.Text = newText;
            textBox.SelectionStart = selectionStart <= textBox.Text.Length ? selectionStart : textBox.Text.Length;
            if (selection is NTextBox)
            {
                if ((selection as NTextBox).MainContent != null && textBox.Text.Length != 0)
                {
                    double output;
                    if (Double.TryParse(textBox.Text, out output))
                    {
                        (selection as NTextBox).MainContent.FontSize = output;
                    }
                }
            }

        }
        private void TextBoxPasting(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(String)))
            {
                String text = (String)e.DataObject.GetData(typeof(String));
                if (!IsTextAllowed(text))
                {
                    e.CancelCommand();
                }
            }
            else
            {
                e.CancelCommand();
            }
        }

        private void BoldBtn_Click(object sender, RoutedEventArgs e)
        {
            if(!(selection is NTextBox)) { return; }
            if ((selection as NTextBox).MainContent.FontWeight == FontWeights.Bold)
            {
                BoldBtn.BorderBrush = Brushes.Transparent;
                (selection as NTextBox).MainContent.FontWeight = FontWeights.Normal;
            }
            else { 
                BoldBtn.BorderBrush = Brushes.DarkCyan;
                (selection as NTextBox).MainContent.FontWeight = FontWeights.Bold;
            }
        }

        private void ItaBtn_Click(object sender, RoutedEventArgs e)
        {
            if (!(selection is NTextBox)) { return; }
            if ((selection as NTextBox).MainContent.FontStyle == FontStyles.Italic)
            {
                ItaBtn.BorderBrush = Brushes.Transparent;
                (selection as NTextBox).MainContent.FontStyle = FontStyles.Normal;
            }
            else
            {
                ItaBtn.BorderBrush = Brushes.DarkCyan;
                (selection as NTextBox).MainContent.FontStyle = FontStyles.Italic;
            }
        }

        private void innerOp_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = IsTextNumeric(e.Text);
        }

        private void innerOp_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            Int32 selectionStart = textBox.SelectionStart;
            Int32 selectionLength = textBox.SelectionLength;
            String newText = String.Empty;
            int count = 0;
            foreach (Char c in textBox.Text.ToCharArray())
            {
                if (Char.IsDigit(c) || Char.IsControl(c) || (c == '.' && count == 0))
                {
                    newText += c;
                    if (c == '.')
                        count += 1;
                }
            }
            textBox.Text = newText;
            textBox.SelectionStart = selectionStart <= textBox.Text.Length ? selectionStart : textBox.Text.Length;
            if (selection is Highlighter)
            {
                if ((selection as Highlighter).outLine != null && textBox.Text.Length != 0)
                {
                    double output;
                    if (Double.TryParse(textBox.Text, out output))
                    {
                        if (output <= 1 && output >= 0) {
                            Highlighter tempref = (selection as Highlighter);
                            SolidColorBrush tempbrush = new SolidColorBrush((tempref.outLine.Fill as SolidColorBrush).Color);
                            tempbrush.Opacity = output;
                            tempref.outLine.Fill = tempbrush;
                        }

                    }
                }
            }
        }

        private void innerOp_Pasting(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(String)))
            {
                String text = (String)e.DataObject.GetData(typeof(String));
                if (!IsTextAllowed(text))
                {
                    e.CancelCommand();
                }
            }
            else
            {
                e.CancelCommand();
            }
        }

        private void outerOp_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = IsTextNumeric(e.Text);
        }

        private void outerOp_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            Int32 selectionStart = textBox.SelectionStart;
            Int32 selectionLength = textBox.SelectionLength;
            String newText = String.Empty;
            int count = 0;
            foreach (Char c in textBox.Text.ToCharArray())
            {
                if (Char.IsDigit(c) || Char.IsControl(c) || (c == '.' && count == 0))
                {
                    newText += c;
                    if (c == '.')
                        count += 1;
                }
            }
            textBox.Text = newText;
            textBox.SelectionStart = selectionStart <= textBox.Text.Length ? selectionStart : textBox.Text.Length;
            if (selection is Highlighter)
            {
                if ((selection as Highlighter).outLine != null && textBox.Text.Length != 0)
                {
                    double output;
                    if (Double.TryParse(textBox.Text, out output))
                    {
                        if (output <= 1 && output >= 0)
                        {
                            Highlighter tempref = (selection as Highlighter);
                            SolidColorBrush tempbrush = new SolidColorBrush((tempref.outLine.Stroke as SolidColorBrush).Color);
                            tempbrush.Opacity = output;
                            tempref.outLine.Stroke = tempbrush;
                        }

                    }
                }
            }
        }

        private void outerOp_Pasting(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(String)))
            {
                String text = (String)e.DataObject.GetData(typeof(String));
                if (!IsTextAllowed(text))
                {
                    e.CancelCommand();
                }
            }
            else
            {
                e.CancelCommand();
            }
        }

        private void HighThickBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = IsTextNumeric(e.Text);
        }

        private void HighThickBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            Int32 selectionStart = textBox.SelectionStart;
            Int32 selectionLength = textBox.SelectionLength;
            String newText = String.Empty;
            int count = 0;
            foreach (Char c in textBox.Text.ToCharArray())
            {
                if (Char.IsDigit(c) || Char.IsControl(c) || (c == '.' && count == 0))
                {
                    newText += c;
                    if (c == '.')
                        count += 1;
                }
            }
            textBox.Text = newText;
            textBox.SelectionStart = selectionStart <= textBox.Text.Length ? selectionStart : textBox.Text.Length;
            if (selection is Highlighter)
            {
                if ((selection as Highlighter).outLine != null && textBox.Text.Length != 0)
                {
                    double output;
                    if (Double.TryParse(textBox.Text, out output))
                    {
                        Highlighter tempref = (selection as Highlighter);
                        tempref.outLine.StrokeThickness = output;
                    }
                }
            }
        }

        private void HighThickBox_Pasting(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(String)))
            {
                String text = (String)e.DataObject.GetData(typeof(String));
                if (!IsTextAllowed(text))
                {
                    e.CancelCommand();
                }
            }
            else
            {
                e.CancelCommand();
            }
        }

        private void HighRoundBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = IsTextNumeric(e.Text);
        }

        private void HighRoundBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            Int32 selectionStart = textBox.SelectionStart;
            Int32 selectionLength = textBox.SelectionLength;
            String newText = String.Empty;
            int count = 0;
            foreach (Char c in textBox.Text.ToCharArray())
            {
                if (Char.IsDigit(c) || Char.IsControl(c) || (c == '.' && count == 0))
                {
                    newText += c;
                    if (c == '.')
                        count += 1;
                }
            }
            textBox.Text = newText;
            textBox.SelectionStart = selectionStart <= textBox.Text.Length ? selectionStart : textBox.Text.Length;
            if (selection is Highlighter)
            {
                if ((selection as Highlighter).outLine != null && textBox.Text.Length != 0)
                {
                    int output;
                    if (Int32.TryParse(textBox.Text, out output))
                    {
                        if (output <= 100 && output >= 0)
                        {
                            Highlighter tempref = (selection as Highlighter);
                            tempref.roundness = output;
                            RectangleGeometry newrp = new RectangleGeometry();
                            newrp.Rect = Resizables.RectToRect(tempref.innerRect);
                            newrp.RadiusX = newrp.RadiusY = Math.Min(newrp.Rect.Width, newrp.Rect.Height) * output / 200;

                            tempref.outLine.Data = newrp;
                        }

                    }
                }
            }
        }

        private void HighRoundBox_Pasting(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(String)))
            {
                String text = (String)e.DataObject.GetData(typeof(String));
                if (!IsTextAllowed(text))
                {
                    e.CancelCommand();
                }
            }
            else
            {
                e.CancelCommand();
            }
        }

        private void UThickBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = IsTextNumeric(e.Text);
        }

        private void UThickBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            Int32 selectionStart = textBox.SelectionStart;
            Int32 selectionLength = textBox.SelectionLength;
            String newText = String.Empty;
            int count = 0;
            foreach (Char c in textBox.Text.ToCharArray())
            {
                if (Char.IsDigit(c) || Char.IsControl(c) || (c == '.' && count == 0))
                {
                    newText += c;
                    if (c == '.')
                        count += 1;
                }
            }
            textBox.Text = newText;
            textBox.SelectionStart = selectionStart <= textBox.Text.Length ? selectionStart : textBox.Text.Length;
            if (selection is Underline)
            {
                if ((selection as Underline).outLine != null && textBox.Text.Length != 0)
                {
                    double output;
                    if (Double.TryParse(textBox.Text, out output))
                    {
                        Underline tempref = (selection as Underline);
                        tempref.innerRect.Height = output;
                        tempref.refreshCurveFromInnerRect();
                    }
                }
            }
        }

        private void URoundBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = IsTextNumeric(e.Text);
        }

        private void URoundBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            Int32 selectionStart = textBox.SelectionStart;
            Int32 selectionLength = textBox.SelectionLength;
            String newText = String.Empty;
            int count = 0;
            foreach (Char c in textBox.Text.ToCharArray())
            {
                if (Char.IsDigit(c) || Char.IsControl(c) || (c == '.' && count == 0))
                {
                    newText += c;
                    if (c == '.')
                        count += 1;
                }
            }
            textBox.Text = newText;
            textBox.SelectionStart = selectionStart <= textBox.Text.Length ? selectionStart : textBox.Text.Length;
            if (selection is Underline)
            {
                if ((selection as Underline).outLine != null && textBox.Text.Length != 0)
                {
                    int output;
                    if (Int32.TryParse(textBox.Text, out output))
                    {
                        if (output <= 100 && output >= 0)
                        {
                            Underline tempref = (selection as Underline);
                            tempref.roundness = output;
                            RectangleGeometry newrp = new RectangleGeometry();
                            newrp.Rect = Resizables.RectToRect(tempref.innerRect);
                            newrp.RadiusX = newrp.RadiusY = Math.Min(newrp.Rect.Width, newrp.Rect.Height) * output / 200;

                            tempref.outLine.Data = newrp;
                        }

                    }
                }
            }
        }

        private void URoundBox_Pasting(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(String)))
            {
                String text = (String)e.DataObject.GetData(typeof(String));
                if (!IsTextAllowed(text))
                {
                    e.CancelCommand();
                }
            }
            else
            {
                e.CancelCommand();
            }
        }

        
        private async void SaveFile_Click(object sender, RoutedEventArgs e)
        {
            if (notePages.Count == 0) { return; }
            
            System.Windows.Forms.SaveFileDialog sfd = new System.Windows.Forms.SaveFileDialog();
            sfd.Filter = "PDF 문서(*.pdf) | *.pdf";
            if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //(sfd.FileName, savedxml)
                List<System.Drawing.Bitmap> ImageArr = new List<System.Drawing.Bitmap>();
                backGroundImgShown = true;
                int tempint = PagesList.SelectedIndex;
                if (tempint == 1)
                {
                    if (currentPage.candidateImages.Count == 0)
                    {
                        RecordArea.innerRect.Fill = Brushes.Transparent;
                        return;
                    }
                    else
                    {
                        RecordArea.innerRect.Fill = new ImageBrush(currentPage.candidateImages[currentPage.MainCandidateImageIndex]);
                    }
                    await Task.Run(async () => await Task.Delay(150));
                }
                killFocus(null);
                for(int i=0; i < PagesList.Items.Count; i++)
                {
                    PagesList.SelectedItem = PagesList.Items[i];
                    await Task.Run(async () => await Task.Delay(400));
                    await exportCap(RecordArea.innerRect);
                    ImageArr.Add(tempbmp);
                }
                PagesList.SelectedItem = PagesList.Items[tempint];




                PdfDocument pdf = new PdfDocument();


                for (int f = 0; f < ImageArr.Count; f++)
                {
                    System.IO.MemoryStream strm = new System.IO.MemoryStream();
                    ImageArr[f].Save(strm, System.Drawing.Imaging.ImageFormat.Png);
                    System.Drawing.Image timg = System.Drawing.Image.FromStream(strm);
                    XImage img = XImage.FromGdiPlusImage(timg);
                    ///XImage img = XImage.FromGdiPlusImage(ImageArr[f]);
                    img.Interpolate = false;
                    int width = img.PixelWidth;
                    int height = img.PixelHeight;
                    PdfSharp.Pdf.PdfPage page = new PdfSharp.Pdf.PdfPage
                    {
                        Width = width,
                        Height = height
                    };
                    
                    pdf.Pages.Add(page);
                    XGraphics xgr = XGraphics.FromPdfPage(pdf.Pages[f]);
                    xgr.DrawImage(img, 0, 0, width, height);
                    img.Dispose();
                    xgr.Dispose();
                }

                
                pdf.Save(sfd.FileName);
                pdf.Dispose();

            }
        }
        private System.Drawing.Bitmap BitmapFromSource(BitmapSource bitmapsource)
        {
            System.Drawing.Bitmap bitmap;
            using (System.IO.MemoryStream outStream = new System.IO.MemoryStream())
            {
                BitmapEncoder enc = new BmpBitmapEncoder();

                enc.Frames.Add(BitmapFrame.Create(bitmapsource));
                enc.Save(outStream);
                bitmap = new System.Drawing.Bitmap(outStream);
            }
            return bitmap;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            globalMouseListener.Abort();
            captureThread.Abort();
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            mouseListenerPause = false;
        }
    }

}
